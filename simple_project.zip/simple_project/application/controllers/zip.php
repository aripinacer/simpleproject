<?php

class zip extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $this->load->library('zip');
        $path = './upload/baground.jpg';

        $this->zip->read_file($path);
        $this->zip->archive($path . '.zip');

        $this->zip->download('my_archive.zip');
    }
}
