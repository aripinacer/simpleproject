<?php
defined('BASEPATH') or exit('No direct script access allowed');
class ftp extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $this->load->library('ftp');

        $config['hostname'] = '';
        $config['username'] = '';
        $config['password'] = '';
        $config['debug']        = TRUE;

        $this->ftp->connect($config);
    }
}
