<?php
defined('BASEPATH') or exit('No direct script access allowed');
class size extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $config['image_library'] = 'gd2';
        $config['source_image'] = './upload/size.jpg';
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = TRUE;
        $config['width']         = 75;
        $config['height']       = 50;

        $this->load->library('image_lib', $config);

        $this->image_lib->resize();
    }
}
