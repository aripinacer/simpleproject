<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Buku extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('buku_m', 'buku');
		$this->load->library('form_validation');
	}

	public function index()
	{
		// === pagination ======//
		//$this->load->library('pagination');
		$jumlah_data = $this->buku->jumlah_data();;
		$config['base_url'] = site_url('buku/index');
		$config['total_rows'] = $jumlah_data;
		$config['per_page'] = 20;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);
		// === end ======//


		$query = $this->buku->get($config['per_page'], $from);
		// $data['header'] = 'Tampil Data Buku';
		// $data['buku'] = $query->result();
		$data = array(
			'header' => 'Tampil Data Buku',
			'buku' => $query->result(),
		);
		$this->load->view('_header', $data);
		$this->load->view('buku_tampil', $data);
		$this->load->view('_footer');
	}

	public function add()
	{
		$data = array(
			'header' => 'Tambah Data Buku'
		);
		$this->load->view('_header', $data);
		$this->load->view('buku_tambah');
		$this->load->view('_footer');
	}

	public function edit($id = null)
	{
		$query = $this->buku->get_edit($id);
		$data = array(
			'header' => 'Edit Data Buku',
			'buku' => $query->row()
		);
		$this->load->view('_header', $data);
		$this->load->view('buku_edit');
		$this->load->view('_footer');
	}

	public function proses()
	{
		$this->form_validation->set_rules('judul', 'judul', 'required');
		$this->form_validation->set_rules('pengarang', 'pengarang', 'required');
		$this->form_validation->set_rules('tahun', 'tahun', 'required');
		if ($this->form_validation->run() != false) {
			if (isset($_POST['add'])) {

				$inputan = $this->input->post(null, TRUE);
				$this->buku->add($inputan);
				log_message('info', 'buku telah diinput');
			} else if (isset($_POST['edit'])) {
				$inputan = $this->input->post(null, TRUE);
				$this->buku->edit($inputan);
			}
			redirect('buku');
		} else {

			$data = array(
				'header' => 'Tambah Data Buku'
			);
			$this->load->view('_header', $data);
			$this->load->view('buku_tambah');
			$this->load->view('_footer');
		}
	}

	public function del($id)
	{
		$this->buku->del($id);
		redirect('buku');
	}
}
