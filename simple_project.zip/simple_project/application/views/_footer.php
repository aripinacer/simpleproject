		</div>
		<div class="footer">
			Copyright aripin
		</div>
		</div>
		</body>

		</html>