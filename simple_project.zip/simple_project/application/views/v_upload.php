<html>

<head>
    <title>upload</title>
</head>

<body>
    <?PHP
    $csrf = array(
        'name' => $this->security->get_csrf_token_name(),
        'hash' => $this->security->get_csrf_hash()
    );
    ?>
    <center>
        <h1>Membuat Upload File Dengan CodeIgniter </h1>
    </center>
    <?php echo $error; ?>

    <?php echo form_open_multipart('upload/aksi_upload'); ?>
    <input type="hidden" name="<?= $csrf['name']; ?>" value="<?= $csrf['hash']; ?>" />
    <input type="file" name="berkas" />

    <br /><br />

    <input type="submit" value="upload" />

    </form>

</body>

</html>