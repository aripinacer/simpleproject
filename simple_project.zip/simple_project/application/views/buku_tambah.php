<?php
$csrf = array(
	'name' => $this->security->get_csrf_token_name(),
	'hash' => $this->security->get_csrf_hash()
);
echo form_open('buku/proses'); ?>
<?php echo validation_errors(); ?>
<table>
	<tr>
		<td>Judul</td>
		<td>:</td>
		<td>
			<?php echo form_input('judul', ''); ?>
		</td>
	</tr>
	<tr>
		<td>Pengarang</td>
		<td>:</td>
		<td>

			<input type="hidden" name="<?= $csrf['name']; ?>" value="<?= $csrf['hash']; ?>" />
			<?php echo form_input('pengarang', ''); ?>
		</td>
	</tr>
	<tr>
		<td>Tahun Terbit</td>
		<td>:</td>
		<td>
			<?php echo form_input(array('type' => 'number', 'name' => 'tahun')); ?>
		</td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td>
			<?php echo form_input(array('type' => 'submit', 'name' => 'add', 'value' => 'Tambah')); ?>
		</td>
	</tr>
</table>
<?php echo form_close(); ?>