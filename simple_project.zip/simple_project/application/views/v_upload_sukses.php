<html>

<head>
    <title>malasngoding.com</title>
</head>

<body>

    <center>
        <h1>SUKSES Upload File Dengan CodeIgniter</h1>
    </center>



</body>

</html>