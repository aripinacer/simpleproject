<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-12 09:55:47 --> Config Class Initialized
INFO - 2021-10-12 09:55:47 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:55:47 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:55:47 --> Utf8 Class Initialized
INFO - 2021-10-12 09:55:47 --> URI Class Initialized
INFO - 2021-10-12 09:55:47 --> Router Class Initialized
INFO - 2021-10-12 09:55:47 --> Output Class Initialized
INFO - 2021-10-12 09:55:47 --> Security Class Initialized
DEBUG - 2021-10-12 09:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:55:47 --> CSRF cookie sent
INFO - 2021-10-12 09:55:47 --> Input Class Initialized
INFO - 2021-10-12 09:55:47 --> Language Class Initialized
INFO - 2021-10-12 09:55:47 --> Loader Class Initialized
INFO - 2021-10-12 09:55:47 --> Helper loaded: url_helper
INFO - 2021-10-12 09:55:47 --> Helper loaded: form_helper
INFO - 2021-10-12 09:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 09:55:47 --> Pagination Class Initialized
INFO - 2021-10-12 09:55:47 --> Controller Class Initialized
INFO - 2021-10-12 09:55:47 --> Database Driver Class Initialized
INFO - 2021-10-12 09:55:47 --> Model "Buku_m" initialized
INFO - 2021-10-12 09:55:47 --> Form Validation Class Initialized
INFO - 2021-10-12 09:55:47 --> Config Class Initialized
INFO - 2021-10-12 09:55:47 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:55:47 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:55:47 --> Utf8 Class Initialized
INFO - 2021-10-12 09:55:47 --> URI Class Initialized
INFO - 2021-10-12 09:55:47 --> Router Class Initialized
INFO - 2021-10-12 09:55:47 --> Output Class Initialized
INFO - 2021-10-12 09:55:47 --> Security Class Initialized
DEBUG - 2021-10-12 09:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:55:47 --> CSRF cookie sent
INFO - 2021-10-12 09:55:47 --> Input Class Initialized
INFO - 2021-10-12 09:55:47 --> Language Class Initialized
INFO - 2021-10-12 09:55:47 --> Loader Class Initialized
INFO - 2021-10-12 09:55:47 --> Helper loaded: url_helper
INFO - 2021-10-12 09:55:47 --> Helper loaded: form_helper
INFO - 2021-10-12 09:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 09:55:47 --> Pagination Class Initialized
INFO - 2021-10-12 09:55:47 --> Controller Class Initialized
INFO - 2021-10-12 09:55:47 --> Database Driver Class Initialized
INFO - 2021-10-12 09:55:47 --> Model "Buku_m" initialized
INFO - 2021-10-12 09:55:47 --> Form Validation Class Initialized
INFO - 2021-10-12 09:55:47 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 09:55:47 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tampil.php
INFO - 2021-10-12 09:55:47 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 09:55:47 --> Final output sent to browser
DEBUG - 2021-10-12 09:55:47 --> Total execution time: 0.0675
INFO - 2021-10-12 09:55:50 --> Config Class Initialized
INFO - 2021-10-12 09:55:50 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:55:50 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:55:50 --> Utf8 Class Initialized
INFO - 2021-10-12 09:55:50 --> URI Class Initialized
INFO - 2021-10-12 09:55:50 --> Router Class Initialized
INFO - 2021-10-12 09:55:50 --> Output Class Initialized
INFO - 2021-10-12 09:55:50 --> Security Class Initialized
DEBUG - 2021-10-12 09:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:55:50 --> CSRF cookie sent
INFO - 2021-10-12 09:55:50 --> Input Class Initialized
INFO - 2021-10-12 09:55:50 --> Language Class Initialized
INFO - 2021-10-12 09:55:50 --> Loader Class Initialized
INFO - 2021-10-12 09:55:50 --> Helper loaded: url_helper
INFO - 2021-10-12 09:55:50 --> Helper loaded: form_helper
INFO - 2021-10-12 09:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 09:55:50 --> Pagination Class Initialized
INFO - 2021-10-12 09:55:50 --> Controller Class Initialized
INFO - 2021-10-12 09:55:50 --> Database Driver Class Initialized
INFO - 2021-10-12 09:55:50 --> Model "Buku_m" initialized
INFO - 2021-10-12 09:55:50 --> Form Validation Class Initialized
INFO - 2021-10-12 09:55:50 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 09:55:50 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tambah.php
INFO - 2021-10-12 09:55:50 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 09:55:50 --> Final output sent to browser
DEBUG - 2021-10-12 09:55:50 --> Total execution time: 0.0795
INFO - 2021-10-12 09:56:03 --> Config Class Initialized
INFO - 2021-10-12 09:56:03 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:56:03 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:56:03 --> Utf8 Class Initialized
INFO - 2021-10-12 09:56:03 --> URI Class Initialized
INFO - 2021-10-12 09:56:03 --> Router Class Initialized
INFO - 2021-10-12 09:56:03 --> Output Class Initialized
INFO - 2021-10-12 09:56:03 --> Security Class Initialized
DEBUG - 2021-10-12 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:56:03 --> CSRF cookie sent
INFO - 2021-10-12 09:56:03 --> CSRF token verified
INFO - 2021-10-12 09:56:03 --> Input Class Initialized
INFO - 2021-10-12 09:56:03 --> Language Class Initialized
INFO - 2021-10-12 09:56:03 --> Loader Class Initialized
INFO - 2021-10-12 09:56:03 --> Helper loaded: url_helper
INFO - 2021-10-12 09:56:03 --> Helper loaded: form_helper
INFO - 2021-10-12 09:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 09:56:03 --> Pagination Class Initialized
INFO - 2021-10-12 09:56:03 --> Controller Class Initialized
INFO - 2021-10-12 09:56:03 --> Database Driver Class Initialized
INFO - 2021-10-12 09:56:03 --> Model "Buku_m" initialized
INFO - 2021-10-12 09:56:03 --> Form Validation Class Initialized
INFO - 2021-10-12 09:56:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-10-12 09:56:03 --> Severity: Notice --> Undefined index: INSERT D:\Xampp\xampp_7.4.22\htdocs\simple_project\system\core\Log.php 180
INFO - 2021-10-12 09:56:03 --> Config Class Initialized
INFO - 2021-10-12 09:56:03 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:56:03 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:56:03 --> Utf8 Class Initialized
INFO - 2021-10-12 09:56:03 --> URI Class Initialized
INFO - 2021-10-12 09:56:03 --> Router Class Initialized
INFO - 2021-10-12 09:56:03 --> Output Class Initialized
INFO - 2021-10-12 09:56:03 --> Security Class Initialized
DEBUG - 2021-10-12 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:56:03 --> CSRF cookie sent
INFO - 2021-10-12 09:56:03 --> Input Class Initialized
INFO - 2021-10-12 09:56:03 --> Language Class Initialized
INFO - 2021-10-12 09:56:03 --> Loader Class Initialized
INFO - 2021-10-12 09:56:03 --> Helper loaded: url_helper
INFO - 2021-10-12 09:56:03 --> Helper loaded: form_helper
INFO - 2021-10-12 09:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 09:56:03 --> Pagination Class Initialized
INFO - 2021-10-12 09:56:03 --> Controller Class Initialized
INFO - 2021-10-12 09:56:03 --> Database Driver Class Initialized
INFO - 2021-10-12 09:56:04 --> Model "Buku_m" initialized
INFO - 2021-10-12 09:56:04 --> Form Validation Class Initialized
INFO - 2021-10-12 09:56:04 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 09:56:04 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tampil.php
INFO - 2021-10-12 09:56:04 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 09:56:04 --> Final output sent to browser
DEBUG - 2021-10-12 09:56:04 --> Total execution time: 0.0651
INFO - 2021-10-12 10:27:26 --> Config Class Initialized
INFO - 2021-10-12 10:27:26 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:27:26 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:27:26 --> Utf8 Class Initialized
INFO - 2021-10-12 10:27:26 --> URI Class Initialized
INFO - 2021-10-12 10:27:26 --> Router Class Initialized
INFO - 2021-10-12 10:27:26 --> Output Class Initialized
INFO - 2021-10-12 10:27:26 --> Security Class Initialized
DEBUG - 2021-10-12 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:27:26 --> CSRF cookie sent
INFO - 2021-10-12 10:27:26 --> Input Class Initialized
INFO - 2021-10-12 10:27:26 --> Language Class Initialized
ERROR - 2021-10-12 10:27:26 --> 404 Page Not Found: Upload/index
INFO - 2021-10-12 10:27:53 --> Config Class Initialized
INFO - 2021-10-12 10:27:53 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:27:53 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:27:53 --> Utf8 Class Initialized
INFO - 2021-10-12 10:27:53 --> URI Class Initialized
INFO - 2021-10-12 10:27:53 --> Router Class Initialized
INFO - 2021-10-12 10:27:53 --> Output Class Initialized
INFO - 2021-10-12 10:27:53 --> Security Class Initialized
DEBUG - 2021-10-12 10:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:27:53 --> CSRF cookie sent
INFO - 2021-10-12 10:27:53 --> Input Class Initialized
INFO - 2021-10-12 10:27:53 --> Language Class Initialized
INFO - 2021-10-12 10:27:53 --> Loader Class Initialized
INFO - 2021-10-12 10:27:53 --> Helper loaded: url_helper
INFO - 2021-10-12 10:27:53 --> Helper loaded: form_helper
INFO - 2021-10-12 10:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:27:53 --> Pagination Class Initialized
INFO - 2021-10-12 10:27:53 --> Controller Class Initialized
INFO - 2021-10-12 10:27:53 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:27:53 --> Final output sent to browser
DEBUG - 2021-10-12 10:27:53 --> Total execution time: 0.0292
INFO - 2021-10-12 10:28:26 --> Config Class Initialized
INFO - 2021-10-12 10:28:26 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:28:26 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:28:26 --> Utf8 Class Initialized
INFO - 2021-10-12 10:28:26 --> URI Class Initialized
INFO - 2021-10-12 10:28:26 --> Router Class Initialized
INFO - 2021-10-12 10:28:26 --> Output Class Initialized
INFO - 2021-10-12 10:28:26 --> Security Class Initialized
DEBUG - 2021-10-12 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:28:26 --> CSRF cookie sent
INFO - 2021-10-12 10:28:26 --> CSRF token verified
INFO - 2021-10-12 10:28:26 --> Input Class Initialized
INFO - 2021-10-12 10:28:26 --> Language Class Initialized
INFO - 2021-10-12 10:28:26 --> Loader Class Initialized
INFO - 2021-10-12 10:28:26 --> Helper loaded: url_helper
INFO - 2021-10-12 10:28:26 --> Helper loaded: form_helper
INFO - 2021-10-12 10:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:28:26 --> Pagination Class Initialized
INFO - 2021-10-12 10:28:26 --> Controller Class Initialized
INFO - 2021-10-12 10:28:26 --> Upload Class Initialized
INFO - 2021-10-12 10:28:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-10-12 10:28:26 --> The upload path does not appear to be valid.
INFO - 2021-10-12 10:28:26 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:28:26 --> Final output sent to browser
DEBUG - 2021-10-12 10:28:26 --> Total execution time: 0.0749
INFO - 2021-10-12 10:30:15 --> Config Class Initialized
INFO - 2021-10-12 10:30:15 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:30:15 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:30:15 --> Utf8 Class Initialized
INFO - 2021-10-12 10:30:15 --> URI Class Initialized
INFO - 2021-10-12 10:30:15 --> Router Class Initialized
INFO - 2021-10-12 10:30:15 --> Output Class Initialized
INFO - 2021-10-12 10:30:15 --> Security Class Initialized
DEBUG - 2021-10-12 10:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:30:15 --> CSRF cookie sent
INFO - 2021-10-12 10:31:11 --> Config Class Initialized
INFO - 2021-10-12 10:31:11 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:31:11 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:31:11 --> Utf8 Class Initialized
INFO - 2021-10-12 10:31:11 --> URI Class Initialized
INFO - 2021-10-12 10:31:11 --> Router Class Initialized
INFO - 2021-10-12 10:31:11 --> Output Class Initialized
INFO - 2021-10-12 10:31:11 --> Security Class Initialized
DEBUG - 2021-10-12 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:31:11 --> CSRF cookie sent
INFO - 2021-10-12 10:33:43 --> Config Class Initialized
INFO - 2021-10-12 10:33:43 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:33:43 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:33:43 --> Utf8 Class Initialized
INFO - 2021-10-12 10:33:43 --> URI Class Initialized
INFO - 2021-10-12 10:33:43 --> Router Class Initialized
INFO - 2021-10-12 10:33:43 --> Output Class Initialized
INFO - 2021-10-12 10:33:43 --> Security Class Initialized
DEBUG - 2021-10-12 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:33:43 --> CSRF cookie sent
INFO - 2021-10-12 10:33:53 --> Config Class Initialized
INFO - 2021-10-12 10:33:53 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:33:53 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:33:53 --> Utf8 Class Initialized
INFO - 2021-10-12 10:33:53 --> URI Class Initialized
INFO - 2021-10-12 10:33:53 --> Router Class Initialized
INFO - 2021-10-12 10:33:53 --> Output Class Initialized
INFO - 2021-10-12 10:33:53 --> Security Class Initialized
DEBUG - 2021-10-12 10:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:33:53 --> CSRF cookie sent
INFO - 2021-10-12 10:33:53 --> Input Class Initialized
INFO - 2021-10-12 10:33:53 --> Language Class Initialized
INFO - 2021-10-12 10:33:53 --> Loader Class Initialized
INFO - 2021-10-12 10:33:53 --> Helper loaded: url_helper
INFO - 2021-10-12 10:33:53 --> Helper loaded: form_helper
INFO - 2021-10-12 10:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:33:53 --> Pagination Class Initialized
INFO - 2021-10-12 10:33:53 --> Controller Class Initialized
INFO - 2021-10-12 10:33:53 --> Upload Class Initialized
INFO - 2021-10-12 10:33:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:33:53 --> You did not select a file to upload.
INFO - 2021-10-12 10:33:53 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:33:53 --> Final output sent to browser
DEBUG - 2021-10-12 10:33:53 --> Total execution time: 0.0320
INFO - 2021-10-12 10:34:05 --> Config Class Initialized
INFO - 2021-10-12 10:34:05 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:34:05 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:34:05 --> Utf8 Class Initialized
INFO - 2021-10-12 10:34:05 --> URI Class Initialized
INFO - 2021-10-12 10:34:05 --> Router Class Initialized
INFO - 2021-10-12 10:34:05 --> Output Class Initialized
INFO - 2021-10-12 10:34:05 --> Security Class Initialized
DEBUG - 2021-10-12 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:34:05 --> CSRF cookie sent
INFO - 2021-10-12 10:34:05 --> CSRF token verified
INFO - 2021-10-12 10:34:05 --> Input Class Initialized
INFO - 2021-10-12 10:34:05 --> Language Class Initialized
INFO - 2021-10-12 10:34:05 --> Loader Class Initialized
INFO - 2021-10-12 10:34:05 --> Helper loaded: url_helper
INFO - 2021-10-12 10:34:05 --> Helper loaded: form_helper
INFO - 2021-10-12 10:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:34:05 --> Pagination Class Initialized
INFO - 2021-10-12 10:34:05 --> Controller Class Initialized
INFO - 2021-10-12 10:34:05 --> Upload Class Initialized
INFO - 2021-10-12 10:34:05 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:34:05 --> Final output sent to browser
DEBUG - 2021-10-12 10:34:05 --> Total execution time: 0.4739
INFO - 2021-10-12 10:34:15 --> Config Class Initialized
INFO - 2021-10-12 10:34:15 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:34:15 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:34:15 --> Utf8 Class Initialized
INFO - 2021-10-12 10:34:15 --> URI Class Initialized
INFO - 2021-10-12 10:34:15 --> Router Class Initialized
INFO - 2021-10-12 10:34:15 --> Output Class Initialized
INFO - 2021-10-12 10:34:15 --> Security Class Initialized
DEBUG - 2021-10-12 10:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:34:15 --> CSRF cookie sent
INFO - 2021-10-12 10:34:15 --> Input Class Initialized
INFO - 2021-10-12 10:34:15 --> Language Class Initialized
INFO - 2021-10-12 10:34:15 --> Loader Class Initialized
INFO - 2021-10-12 10:34:15 --> Helper loaded: url_helper
INFO - 2021-10-12 10:34:15 --> Helper loaded: form_helper
INFO - 2021-10-12 10:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:34:15 --> Pagination Class Initialized
INFO - 2021-10-12 10:34:15 --> Controller Class Initialized
INFO - 2021-10-12 10:34:15 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:34:15 --> Final output sent to browser
DEBUG - 2021-10-12 10:34:15 --> Total execution time: 0.0263
INFO - 2021-10-12 10:34:24 --> Config Class Initialized
INFO - 2021-10-12 10:34:24 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:34:24 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:34:24 --> Utf8 Class Initialized
INFO - 2021-10-12 10:34:24 --> URI Class Initialized
INFO - 2021-10-12 10:34:24 --> Router Class Initialized
INFO - 2021-10-12 10:34:24 --> Output Class Initialized
INFO - 2021-10-12 10:34:24 --> Security Class Initialized
DEBUG - 2021-10-12 10:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:34:24 --> CSRF cookie sent
INFO - 2021-10-12 10:34:24 --> CSRF token verified
INFO - 2021-10-12 10:34:24 --> Input Class Initialized
INFO - 2021-10-12 10:34:24 --> Language Class Initialized
INFO - 2021-10-12 10:34:24 --> Loader Class Initialized
INFO - 2021-10-12 10:34:24 --> Helper loaded: url_helper
INFO - 2021-10-12 10:34:24 --> Helper loaded: form_helper
INFO - 2021-10-12 10:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:34:24 --> Pagination Class Initialized
INFO - 2021-10-12 10:34:24 --> Controller Class Initialized
INFO - 2021-10-12 10:34:24 --> Upload Class Initialized
INFO - 2021-10-12 10:34:24 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:34:24 --> Final output sent to browser
DEBUG - 2021-10-12 10:34:24 --> Total execution time: 0.0314
INFO - 2021-10-12 10:35:16 --> Config Class Initialized
INFO - 2021-10-12 10:35:16 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:16 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:16 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:16 --> URI Class Initialized
DEBUG - 2021-10-12 10:35:16 --> No URI present. Default controller set.
INFO - 2021-10-12 10:35:16 --> Router Class Initialized
INFO - 2021-10-12 10:35:16 --> Output Class Initialized
INFO - 2021-10-12 10:35:16 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:16 --> CSRF cookie sent
INFO - 2021-10-12 10:35:16 --> Input Class Initialized
INFO - 2021-10-12 10:35:16 --> Language Class Initialized
INFO - 2021-10-12 10:35:16 --> Loader Class Initialized
INFO - 2021-10-12 10:35:16 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:16 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:16 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:16 --> Controller Class Initialized
INFO - 2021-10-12 10:35:16 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:16 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\home.php
INFO - 2021-10-12 10:35:16 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:16 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:16 --> Total execution time: 0.0622
INFO - 2021-10-12 10:35:18 --> Config Class Initialized
INFO - 2021-10-12 10:35:18 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:18 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:18 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:18 --> URI Class Initialized
INFO - 2021-10-12 10:35:18 --> Router Class Initialized
INFO - 2021-10-12 10:35:18 --> Output Class Initialized
INFO - 2021-10-12 10:35:18 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:18 --> CSRF cookie sent
INFO - 2021-10-12 10:35:18 --> Input Class Initialized
INFO - 2021-10-12 10:35:18 --> Language Class Initialized
INFO - 2021-10-12 10:35:18 --> Loader Class Initialized
INFO - 2021-10-12 10:35:18 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:18 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:18 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:18 --> Controller Class Initialized
INFO - 2021-10-12 10:35:18 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:18 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\home.php
INFO - 2021-10-12 10:35:18 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:18 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:18 --> Total execution time: 0.0300
INFO - 2021-10-12 10:35:19 --> Config Class Initialized
INFO - 2021-10-12 10:35:19 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:19 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:19 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:19 --> URI Class Initialized
INFO - 2021-10-12 10:35:19 --> Router Class Initialized
INFO - 2021-10-12 10:35:19 --> Output Class Initialized
INFO - 2021-10-12 10:35:19 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:19 --> CSRF cookie sent
INFO - 2021-10-12 10:35:19 --> Input Class Initialized
INFO - 2021-10-12 10:35:19 --> Language Class Initialized
INFO - 2021-10-12 10:35:19 --> Loader Class Initialized
INFO - 2021-10-12 10:35:19 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:19 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:19 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:19 --> Controller Class Initialized
INFO - 2021-10-12 10:35:19 --> Database Driver Class Initialized
INFO - 2021-10-12 10:35:19 --> Model "Buku_m" initialized
INFO - 2021-10-12 10:35:19 --> Form Validation Class Initialized
INFO - 2021-10-12 10:35:19 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:19 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tampil.php
INFO - 2021-10-12 10:35:19 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:19 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:19 --> Total execution time: 0.0463
INFO - 2021-10-12 10:35:24 --> Config Class Initialized
INFO - 2021-10-12 10:35:24 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:24 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:24 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:24 --> URI Class Initialized
INFO - 2021-10-12 10:35:24 --> Router Class Initialized
INFO - 2021-10-12 10:35:24 --> Output Class Initialized
INFO - 2021-10-12 10:35:24 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:24 --> CSRF cookie sent
INFO - 2021-10-12 10:35:24 --> Input Class Initialized
INFO - 2021-10-12 10:35:24 --> Language Class Initialized
INFO - 2021-10-12 10:35:24 --> Loader Class Initialized
INFO - 2021-10-12 10:35:24 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:24 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:24 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:24 --> Controller Class Initialized
INFO - 2021-10-12 10:35:24 --> Database Driver Class Initialized
INFO - 2021-10-12 10:35:24 --> Model "Buku_m" initialized
INFO - 2021-10-12 10:35:24 --> Form Validation Class Initialized
INFO - 2021-10-12 10:35:24 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:24 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tambah.php
INFO - 2021-10-12 10:35:24 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:24 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:24 --> Total execution time: 0.0521
INFO - 2021-10-12 10:35:30 --> Config Class Initialized
INFO - 2021-10-12 10:35:30 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:30 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:30 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:30 --> URI Class Initialized
INFO - 2021-10-12 10:35:30 --> Router Class Initialized
INFO - 2021-10-12 10:35:30 --> Output Class Initialized
INFO - 2021-10-12 10:35:30 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:30 --> CSRF cookie sent
INFO - 2021-10-12 10:35:30 --> CSRF token verified
INFO - 2021-10-12 10:35:30 --> Input Class Initialized
INFO - 2021-10-12 10:35:30 --> Language Class Initialized
INFO - 2021-10-12 10:35:30 --> Loader Class Initialized
INFO - 2021-10-12 10:35:30 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:30 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:30 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:30 --> Controller Class Initialized
INFO - 2021-10-12 10:35:30 --> Database Driver Class Initialized
INFO - 2021-10-12 10:35:30 --> Model "Buku_m" initialized
INFO - 2021-10-12 10:35:30 --> Form Validation Class Initialized
INFO - 2021-10-12 10:35:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-10-12 10:35:30 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:30 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tambah.php
INFO - 2021-10-12 10:35:30 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:30 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:30 --> Total execution time: 0.0601
INFO - 2021-10-12 10:35:39 --> Config Class Initialized
INFO - 2021-10-12 10:35:39 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:39 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:39 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:39 --> URI Class Initialized
INFO - 2021-10-12 10:35:39 --> Router Class Initialized
INFO - 2021-10-12 10:35:39 --> Output Class Initialized
INFO - 2021-10-12 10:35:39 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:39 --> CSRF cookie sent
INFO - 2021-10-12 10:35:39 --> CSRF token verified
INFO - 2021-10-12 10:35:39 --> Input Class Initialized
INFO - 2021-10-12 10:35:39 --> Language Class Initialized
INFO - 2021-10-12 10:35:39 --> Loader Class Initialized
INFO - 2021-10-12 10:35:39 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:39 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:39 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:39 --> Controller Class Initialized
INFO - 2021-10-12 10:35:39 --> Database Driver Class Initialized
INFO - 2021-10-12 10:35:39 --> Model "Buku_m" initialized
INFO - 2021-10-12 10:35:39 --> Form Validation Class Initialized
INFO - 2021-10-12 10:35:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-10-12 10:35:40 --> buku telah diinput
INFO - 2021-10-12 10:35:40 --> Config Class Initialized
INFO - 2021-10-12 10:35:40 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:35:40 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:35:40 --> Utf8 Class Initialized
INFO - 2021-10-12 10:35:40 --> URI Class Initialized
INFO - 2021-10-12 10:35:40 --> Router Class Initialized
INFO - 2021-10-12 10:35:40 --> Output Class Initialized
INFO - 2021-10-12 10:35:40 --> Security Class Initialized
DEBUG - 2021-10-12 10:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:35:40 --> CSRF cookie sent
INFO - 2021-10-12 10:35:40 --> Input Class Initialized
INFO - 2021-10-12 10:35:40 --> Language Class Initialized
INFO - 2021-10-12 10:35:40 --> Loader Class Initialized
INFO - 2021-10-12 10:35:40 --> Helper loaded: url_helper
INFO - 2021-10-12 10:35:40 --> Helper loaded: form_helper
INFO - 2021-10-12 10:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:35:40 --> Pagination Class Initialized
INFO - 2021-10-12 10:35:40 --> Controller Class Initialized
INFO - 2021-10-12 10:35:40 --> Database Driver Class Initialized
INFO - 2021-10-12 10:35:40 --> Model "Buku_m" initialized
INFO - 2021-10-12 10:35:40 --> Form Validation Class Initialized
INFO - 2021-10-12 10:35:40 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-12 10:35:40 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tampil.php
INFO - 2021-10-12 10:35:40 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-12 10:35:40 --> Final output sent to browser
DEBUG - 2021-10-12 10:35:40 --> Total execution time: 0.0855
INFO - 2021-10-12 10:37:50 --> Config Class Initialized
INFO - 2021-10-12 10:37:50 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:37:50 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:37:50 --> Utf8 Class Initialized
INFO - 2021-10-12 10:37:50 --> URI Class Initialized
INFO - 2021-10-12 10:37:50 --> Router Class Initialized
INFO - 2021-10-12 10:37:50 --> Output Class Initialized
INFO - 2021-10-12 10:37:50 --> Security Class Initialized
DEBUG - 2021-10-12 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:37:50 --> CSRF cookie sent
INFO - 2021-10-12 10:37:50 --> Input Class Initialized
INFO - 2021-10-12 10:37:50 --> Language Class Initialized
INFO - 2021-10-12 10:37:50 --> Loader Class Initialized
INFO - 2021-10-12 10:37:50 --> Helper loaded: url_helper
INFO - 2021-10-12 10:37:50 --> Helper loaded: form_helper
INFO - 2021-10-12 10:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:37:50 --> Pagination Class Initialized
INFO - 2021-10-12 10:37:50 --> Controller Class Initialized
INFO - 2021-10-12 10:37:50 --> Upload Class Initialized
INFO - 2021-10-12 10:37:50 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:37:50 --> You did not select a file to upload.
INFO - 2021-10-12 10:37:50 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:37:50 --> Final output sent to browser
DEBUG - 2021-10-12 10:37:50 --> Total execution time: 0.0326
INFO - 2021-10-12 10:37:58 --> Config Class Initialized
INFO - 2021-10-12 10:37:58 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:37:58 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:37:58 --> Utf8 Class Initialized
INFO - 2021-10-12 10:37:58 --> URI Class Initialized
INFO - 2021-10-12 10:37:58 --> Router Class Initialized
INFO - 2021-10-12 10:37:58 --> Output Class Initialized
INFO - 2021-10-12 10:37:58 --> Security Class Initialized
DEBUG - 2021-10-12 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:37:58 --> CSRF cookie sent
INFO - 2021-10-12 10:37:58 --> CSRF token verified
INFO - 2021-10-12 10:37:58 --> Input Class Initialized
INFO - 2021-10-12 10:37:58 --> Language Class Initialized
INFO - 2021-10-12 10:37:58 --> Loader Class Initialized
INFO - 2021-10-12 10:37:58 --> Helper loaded: url_helper
INFO - 2021-10-12 10:37:58 --> Helper loaded: form_helper
INFO - 2021-10-12 10:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:37:58 --> Pagination Class Initialized
INFO - 2021-10-12 10:37:58 --> Controller Class Initialized
INFO - 2021-10-12 10:37:58 --> Upload Class Initialized
INFO - 2021-10-12 10:37:58 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:37:58 --> Final output sent to browser
DEBUG - 2021-10-12 10:37:58 --> Total execution time: 0.0344
INFO - 2021-10-12 10:46:36 --> Config Class Initialized
INFO - 2021-10-12 10:46:36 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:46:36 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:46:36 --> Utf8 Class Initialized
INFO - 2021-10-12 10:46:36 --> URI Class Initialized
INFO - 2021-10-12 10:46:36 --> Router Class Initialized
INFO - 2021-10-12 10:46:36 --> Output Class Initialized
INFO - 2021-10-12 10:46:36 --> Security Class Initialized
DEBUG - 2021-10-12 10:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:46:36 --> CSRF cookie sent
INFO - 2021-10-12 10:46:51 --> Config Class Initialized
INFO - 2021-10-12 10:46:51 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:46:51 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:46:51 --> Utf8 Class Initialized
INFO - 2021-10-12 10:46:51 --> URI Class Initialized
INFO - 2021-10-12 10:46:51 --> Router Class Initialized
INFO - 2021-10-12 10:46:51 --> Output Class Initialized
INFO - 2021-10-12 10:46:51 --> Security Class Initialized
DEBUG - 2021-10-12 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:46:51 --> CSRF cookie sent
INFO - 2021-10-12 10:46:51 --> Input Class Initialized
INFO - 2021-10-12 10:46:51 --> Language Class Initialized
INFO - 2021-10-12 10:46:51 --> Loader Class Initialized
INFO - 2021-10-12 10:46:51 --> Helper loaded: url_helper
INFO - 2021-10-12 10:46:51 --> Helper loaded: form_helper
INFO - 2021-10-12 10:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:46:51 --> Pagination Class Initialized
INFO - 2021-10-12 10:46:51 --> Controller Class Initialized
INFO - 2021-10-12 10:46:51 --> Upload Class Initialized
INFO - 2021-10-12 10:46:51 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:46:51 --> You did not select a file to upload.
INFO - 2021-10-12 10:46:51 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:46:51 --> Final output sent to browser
DEBUG - 2021-10-12 10:46:51 --> Total execution time: 0.0274
INFO - 2021-10-12 10:47:04 --> Config Class Initialized
INFO - 2021-10-12 10:47:04 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:04 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:04 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:04 --> URI Class Initialized
INFO - 2021-10-12 10:47:04 --> Router Class Initialized
INFO - 2021-10-12 10:47:04 --> Output Class Initialized
INFO - 2021-10-12 10:47:04 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:04 --> CSRF cookie sent
INFO - 2021-10-12 10:47:04 --> CSRF token verified
INFO - 2021-10-12 10:47:04 --> Input Class Initialized
INFO - 2021-10-12 10:47:04 --> Language Class Initialized
INFO - 2021-10-12 10:47:04 --> Loader Class Initialized
INFO - 2021-10-12 10:47:04 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:04 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:04 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:04 --> Controller Class Initialized
INFO - 2021-10-12 10:47:04 --> Upload Class Initialized
INFO - 2021-10-12 10:47:04 --> Language file loaded: language/english/upload_lang.php
INFO - 2021-10-12 10:47:04 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2021-10-12 10:47:04 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:47:04 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:04 --> Total execution time: 0.0392
INFO - 2021-10-12 10:47:13 --> Config Class Initialized
INFO - 2021-10-12 10:47:13 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:13 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:13 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:13 --> URI Class Initialized
INFO - 2021-10-12 10:47:13 --> Router Class Initialized
INFO - 2021-10-12 10:47:13 --> Output Class Initialized
INFO - 2021-10-12 10:47:13 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:13 --> CSRF cookie sent
INFO - 2021-10-12 10:47:13 --> CSRF token verified
INFO - 2021-10-12 10:47:13 --> Input Class Initialized
INFO - 2021-10-12 10:47:13 --> Language Class Initialized
INFO - 2021-10-12 10:47:13 --> Loader Class Initialized
INFO - 2021-10-12 10:47:13 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:13 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:13 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:13 --> Controller Class Initialized
INFO - 2021-10-12 10:47:13 --> Upload Class Initialized
INFO - 2021-10-12 10:47:13 --> Language file loaded: language/english/upload_lang.php
INFO - 2021-10-12 10:47:13 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2021-10-12 10:47:13 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:47:13 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:13 --> Total execution time: 0.0328
INFO - 2021-10-12 10:47:21 --> Config Class Initialized
INFO - 2021-10-12 10:47:21 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:21 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:21 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:21 --> URI Class Initialized
INFO - 2021-10-12 10:47:21 --> Router Class Initialized
INFO - 2021-10-12 10:47:21 --> Output Class Initialized
INFO - 2021-10-12 10:47:21 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:21 --> CSRF cookie sent
INFO - 2021-10-12 10:47:21 --> CSRF token verified
INFO - 2021-10-12 10:47:21 --> Input Class Initialized
INFO - 2021-10-12 10:47:21 --> Language Class Initialized
INFO - 2021-10-12 10:47:21 --> Loader Class Initialized
INFO - 2021-10-12 10:47:21 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:21 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:21 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:21 --> Controller Class Initialized
INFO - 2021-10-12 10:47:21 --> Upload Class Initialized
INFO - 2021-10-12 10:47:21 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:47:21 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:21 --> Total execution time: 0.0323
INFO - 2021-10-12 10:47:32 --> Config Class Initialized
INFO - 2021-10-12 10:47:32 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:32 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:32 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:32 --> URI Class Initialized
INFO - 2021-10-12 10:47:32 --> Router Class Initialized
INFO - 2021-10-12 10:47:32 --> Output Class Initialized
INFO - 2021-10-12 10:47:32 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:32 --> CSRF cookie sent
INFO - 2021-10-12 10:47:32 --> Input Class Initialized
INFO - 2021-10-12 10:47:32 --> Language Class Initialized
INFO - 2021-10-12 10:47:32 --> Loader Class Initialized
INFO - 2021-10-12 10:47:32 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:32 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:32 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:32 --> Controller Class Initialized
INFO - 2021-10-12 10:47:32 --> Upload Class Initialized
INFO - 2021-10-12 10:47:32 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:47:32 --> You did not select a file to upload.
INFO - 2021-10-12 10:47:32 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:47:32 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:32 --> Total execution time: 0.0284
INFO - 2021-10-12 10:47:40 --> Config Class Initialized
INFO - 2021-10-12 10:47:40 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:40 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:40 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:40 --> URI Class Initialized
INFO - 2021-10-12 10:47:40 --> Router Class Initialized
INFO - 2021-10-12 10:47:40 --> Output Class Initialized
INFO - 2021-10-12 10:47:40 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:40 --> CSRF cookie sent
INFO - 2021-10-12 10:47:40 --> Input Class Initialized
INFO - 2021-10-12 10:47:40 --> Language Class Initialized
INFO - 2021-10-12 10:47:40 --> Loader Class Initialized
INFO - 2021-10-12 10:47:40 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:40 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:40 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:40 --> Controller Class Initialized
INFO - 2021-10-12 10:47:40 --> Upload Class Initialized
INFO - 2021-10-12 10:47:40 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:47:40 --> You did not select a file to upload.
INFO - 2021-10-12 10:47:40 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:47:40 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:40 --> Total execution time: 0.0286
INFO - 2021-10-12 10:47:51 --> Config Class Initialized
INFO - 2021-10-12 10:47:51 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:51 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:51 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:51 --> URI Class Initialized
INFO - 2021-10-12 10:47:51 --> Router Class Initialized
INFO - 2021-10-12 10:47:51 --> Output Class Initialized
INFO - 2021-10-12 10:47:51 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:51 --> CSRF cookie sent
INFO - 2021-10-12 10:47:51 --> CSRF token verified
INFO - 2021-10-12 10:47:51 --> Input Class Initialized
INFO - 2021-10-12 10:47:51 --> Language Class Initialized
INFO - 2021-10-12 10:47:51 --> Loader Class Initialized
INFO - 2021-10-12 10:47:51 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:51 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:51 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:51 --> Controller Class Initialized
INFO - 2021-10-12 10:47:51 --> Upload Class Initialized
INFO - 2021-10-12 10:47:51 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:47:51 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:51 --> Total execution time: 0.0325
INFO - 2021-10-12 10:47:57 --> Config Class Initialized
INFO - 2021-10-12 10:47:57 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:47:57 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:47:57 --> Utf8 Class Initialized
INFO - 2021-10-12 10:47:57 --> URI Class Initialized
INFO - 2021-10-12 10:47:57 --> Router Class Initialized
INFO - 2021-10-12 10:47:57 --> Output Class Initialized
INFO - 2021-10-12 10:47:57 --> Security Class Initialized
DEBUG - 2021-10-12 10:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:47:57 --> CSRF cookie sent
INFO - 2021-10-12 10:47:57 --> Input Class Initialized
INFO - 2021-10-12 10:47:57 --> Language Class Initialized
INFO - 2021-10-12 10:47:57 --> Loader Class Initialized
INFO - 2021-10-12 10:47:57 --> Helper loaded: url_helper
INFO - 2021-10-12 10:47:57 --> Helper loaded: form_helper
INFO - 2021-10-12 10:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:47:57 --> Pagination Class Initialized
INFO - 2021-10-12 10:47:57 --> Controller Class Initialized
INFO - 2021-10-12 10:47:57 --> Upload Class Initialized
INFO - 2021-10-12 10:47:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:47:57 --> You did not select a file to upload.
INFO - 2021-10-12 10:47:57 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:47:57 --> Final output sent to browser
DEBUG - 2021-10-12 10:47:57 --> Total execution time: 0.0272
INFO - 2021-10-12 10:48:05 --> Config Class Initialized
INFO - 2021-10-12 10:48:05 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:05 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:05 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:05 --> URI Class Initialized
INFO - 2021-10-12 10:48:05 --> Router Class Initialized
INFO - 2021-10-12 10:48:05 --> Output Class Initialized
INFO - 2021-10-12 10:48:05 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:05 --> CSRF cookie sent
INFO - 2021-10-12 10:48:05 --> Input Class Initialized
INFO - 2021-10-12 10:48:05 --> Language Class Initialized
INFO - 2021-10-12 10:48:05 --> Loader Class Initialized
INFO - 2021-10-12 10:48:05 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:05 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:05 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:05 --> Controller Class Initialized
INFO - 2021-10-12 10:48:05 --> Upload Class Initialized
INFO - 2021-10-12 10:48:05 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:05 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:05 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:05 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:05 --> Total execution time: 0.0263
INFO - 2021-10-12 10:48:06 --> Config Class Initialized
INFO - 2021-10-12 10:48:06 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:06 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:06 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:06 --> URI Class Initialized
INFO - 2021-10-12 10:48:06 --> Router Class Initialized
INFO - 2021-10-12 10:48:06 --> Output Class Initialized
INFO - 2021-10-12 10:48:06 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:06 --> CSRF cookie sent
INFO - 2021-10-12 10:48:06 --> Input Class Initialized
INFO - 2021-10-12 10:48:06 --> Language Class Initialized
INFO - 2021-10-12 10:48:06 --> Loader Class Initialized
INFO - 2021-10-12 10:48:06 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:06 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:06 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:06 --> Controller Class Initialized
INFO - 2021-10-12 10:48:06 --> Upload Class Initialized
INFO - 2021-10-12 10:48:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:06 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:06 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:06 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:06 --> Total execution time: 0.0297
INFO - 2021-10-12 10:48:07 --> Config Class Initialized
INFO - 2021-10-12 10:48:07 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:07 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:07 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:07 --> URI Class Initialized
INFO - 2021-10-12 10:48:07 --> Router Class Initialized
INFO - 2021-10-12 10:48:07 --> Output Class Initialized
INFO - 2021-10-12 10:48:07 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:07 --> CSRF cookie sent
INFO - 2021-10-12 10:48:07 --> Input Class Initialized
INFO - 2021-10-12 10:48:07 --> Language Class Initialized
INFO - 2021-10-12 10:48:07 --> Loader Class Initialized
INFO - 2021-10-12 10:48:07 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:07 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:07 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:07 --> Controller Class Initialized
INFO - 2021-10-12 10:48:07 --> Upload Class Initialized
INFO - 2021-10-12 10:48:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:07 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:07 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:07 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:07 --> Total execution time: 0.0296
INFO - 2021-10-12 10:48:08 --> Config Class Initialized
INFO - 2021-10-12 10:48:08 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:08 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:08 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:08 --> URI Class Initialized
INFO - 2021-10-12 10:48:08 --> Router Class Initialized
INFO - 2021-10-12 10:48:08 --> Output Class Initialized
INFO - 2021-10-12 10:48:08 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:08 --> CSRF cookie sent
INFO - 2021-10-12 10:48:08 --> Input Class Initialized
INFO - 2021-10-12 10:48:08 --> Language Class Initialized
INFO - 2021-10-12 10:48:08 --> Loader Class Initialized
INFO - 2021-10-12 10:48:08 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:08 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:08 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:08 --> Controller Class Initialized
INFO - 2021-10-12 10:48:08 --> Upload Class Initialized
INFO - 2021-10-12 10:48:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:08 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:08 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:08 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:08 --> Total execution time: 0.0274
INFO - 2021-10-12 10:48:08 --> Config Class Initialized
INFO - 2021-10-12 10:48:08 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:08 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:08 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:08 --> URI Class Initialized
INFO - 2021-10-12 10:48:08 --> Router Class Initialized
INFO - 2021-10-12 10:48:08 --> Output Class Initialized
INFO - 2021-10-12 10:48:08 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:08 --> CSRF cookie sent
INFO - 2021-10-12 10:48:08 --> Input Class Initialized
INFO - 2021-10-12 10:48:08 --> Language Class Initialized
INFO - 2021-10-12 10:48:08 --> Loader Class Initialized
INFO - 2021-10-12 10:48:08 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:08 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:08 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:08 --> Controller Class Initialized
INFO - 2021-10-12 10:48:08 --> Upload Class Initialized
INFO - 2021-10-12 10:48:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:08 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:08 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:08 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:08 --> Total execution time: 0.0268
INFO - 2021-10-12 10:48:09 --> Config Class Initialized
INFO - 2021-10-12 10:48:09 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:09 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:09 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:09 --> URI Class Initialized
INFO - 2021-10-12 10:48:09 --> Router Class Initialized
INFO - 2021-10-12 10:48:09 --> Output Class Initialized
INFO - 2021-10-12 10:48:09 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:09 --> CSRF cookie sent
INFO - 2021-10-12 10:48:09 --> Input Class Initialized
INFO - 2021-10-12 10:48:09 --> Language Class Initialized
INFO - 2021-10-12 10:48:09 --> Loader Class Initialized
INFO - 2021-10-12 10:48:09 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:09 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:09 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:09 --> Controller Class Initialized
INFO - 2021-10-12 10:48:09 --> Upload Class Initialized
INFO - 2021-10-12 10:48:09 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:09 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:09 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:09 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:09 --> Total execution time: 0.0270
INFO - 2021-10-12 10:48:36 --> Config Class Initialized
INFO - 2021-10-12 10:48:36 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:36 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:36 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:36 --> URI Class Initialized
INFO - 2021-10-12 10:48:36 --> Router Class Initialized
INFO - 2021-10-12 10:48:36 --> Output Class Initialized
INFO - 2021-10-12 10:48:36 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:36 --> CSRF cookie sent
INFO - 2021-10-12 10:48:36 --> Input Class Initialized
INFO - 2021-10-12 10:48:36 --> Language Class Initialized
INFO - 2021-10-12 10:48:36 --> Loader Class Initialized
INFO - 2021-10-12 10:48:36 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:36 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:36 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:36 --> Controller Class Initialized
INFO - 2021-10-12 10:48:36 --> Upload Class Initialized
INFO - 2021-10-12 10:48:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:48:36 --> You did not select a file to upload.
INFO - 2021-10-12 10:48:36 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:48:36 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:36 --> Total execution time: 0.0301
INFO - 2021-10-12 10:48:58 --> Config Class Initialized
INFO - 2021-10-12 10:48:58 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:48:58 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:48:58 --> Utf8 Class Initialized
INFO - 2021-10-12 10:48:58 --> URI Class Initialized
INFO - 2021-10-12 10:48:58 --> Router Class Initialized
INFO - 2021-10-12 10:48:58 --> Output Class Initialized
INFO - 2021-10-12 10:48:58 --> Security Class Initialized
DEBUG - 2021-10-12 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:48:58 --> CSRF cookie sent
INFO - 2021-10-12 10:48:58 --> CSRF token verified
INFO - 2021-10-12 10:48:58 --> Input Class Initialized
INFO - 2021-10-12 10:48:58 --> Language Class Initialized
INFO - 2021-10-12 10:48:58 --> Loader Class Initialized
INFO - 2021-10-12 10:48:58 --> Helper loaded: url_helper
INFO - 2021-10-12 10:48:58 --> Helper loaded: form_helper
INFO - 2021-10-12 10:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:48:58 --> Pagination Class Initialized
INFO - 2021-10-12 10:48:58 --> Controller Class Initialized
INFO - 2021-10-12 10:48:58 --> Upload Class Initialized
INFO - 2021-10-12 10:48:58 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:48:58 --> Final output sent to browser
DEBUG - 2021-10-12 10:48:58 --> Total execution time: 0.0349
INFO - 2021-10-12 10:49:46 --> Config Class Initialized
INFO - 2021-10-12 10:49:46 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:49:46 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:49:46 --> Utf8 Class Initialized
INFO - 2021-10-12 10:49:46 --> URI Class Initialized
INFO - 2021-10-12 10:49:46 --> Router Class Initialized
INFO - 2021-10-12 10:49:46 --> Output Class Initialized
INFO - 2021-10-12 10:49:46 --> Security Class Initialized
DEBUG - 2021-10-12 10:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:49:46 --> CSRF cookie sent
INFO - 2021-10-12 10:49:55 --> Config Class Initialized
INFO - 2021-10-12 10:49:55 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:49:55 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:49:55 --> Utf8 Class Initialized
INFO - 2021-10-12 10:49:55 --> URI Class Initialized
INFO - 2021-10-12 10:49:55 --> Router Class Initialized
INFO - 2021-10-12 10:49:55 --> Output Class Initialized
INFO - 2021-10-12 10:49:55 --> Security Class Initialized
DEBUG - 2021-10-12 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:49:55 --> CSRF cookie sent
INFO - 2021-10-12 10:49:55 --> Input Class Initialized
INFO - 2021-10-12 10:49:55 --> Language Class Initialized
INFO - 2021-10-12 10:49:55 --> Loader Class Initialized
INFO - 2021-10-12 10:49:55 --> Helper loaded: url_helper
INFO - 2021-10-12 10:49:55 --> Helper loaded: form_helper
INFO - 2021-10-12 10:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:49:55 --> Pagination Class Initialized
INFO - 2021-10-12 10:49:55 --> Controller Class Initialized
INFO - 2021-10-12 10:49:55 --> Upload Class Initialized
INFO - 2021-10-12 10:49:55 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2021-10-12 10:49:55 --> You did not select a file to upload.
INFO - 2021-10-12 10:49:55 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload.php
INFO - 2021-10-12 10:49:55 --> Final output sent to browser
DEBUG - 2021-10-12 10:49:55 --> Total execution time: 0.0266
INFO - 2021-10-12 10:50:03 --> Config Class Initialized
INFO - 2021-10-12 10:50:03 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:50:03 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:50:03 --> Utf8 Class Initialized
INFO - 2021-10-12 10:50:03 --> URI Class Initialized
INFO - 2021-10-12 10:50:03 --> Router Class Initialized
INFO - 2021-10-12 10:50:03 --> Output Class Initialized
INFO - 2021-10-12 10:50:03 --> Security Class Initialized
DEBUG - 2021-10-12 10:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:50:03 --> CSRF cookie sent
INFO - 2021-10-12 10:50:03 --> CSRF token verified
INFO - 2021-10-12 10:50:03 --> Input Class Initialized
INFO - 2021-10-12 10:50:03 --> Language Class Initialized
INFO - 2021-10-12 10:50:03 --> Loader Class Initialized
INFO - 2021-10-12 10:50:03 --> Helper loaded: url_helper
INFO - 2021-10-12 10:50:03 --> Helper loaded: form_helper
INFO - 2021-10-12 10:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:50:03 --> Pagination Class Initialized
INFO - 2021-10-12 10:50:03 --> Controller Class Initialized
INFO - 2021-10-12 10:50:03 --> Upload Class Initialized
INFO - 2021-10-12 10:50:03 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:50:03 --> Final output sent to browser
DEBUG - 2021-10-12 10:50:03 --> Total execution time: 0.0322
INFO - 2021-10-12 10:50:12 --> Config Class Initialized
INFO - 2021-10-12 10:50:12 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:50:12 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:50:12 --> Utf8 Class Initialized
INFO - 2021-10-12 10:50:12 --> URI Class Initialized
INFO - 2021-10-12 10:50:12 --> Router Class Initialized
INFO - 2021-10-12 10:50:12 --> Output Class Initialized
INFO - 2021-10-12 10:50:12 --> Security Class Initialized
DEBUG - 2021-10-12 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:50:12 --> CSRF cookie sent
INFO - 2021-10-12 10:51:50 --> Config Class Initialized
INFO - 2021-10-12 10:51:50 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:51:50 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:51:50 --> Utf8 Class Initialized
INFO - 2021-10-12 10:51:50 --> URI Class Initialized
INFO - 2021-10-12 10:51:50 --> Router Class Initialized
INFO - 2021-10-12 10:51:50 --> Output Class Initialized
INFO - 2021-10-12 10:51:50 --> Security Class Initialized
DEBUG - 2021-10-12 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:51:50 --> Input Class Initialized
INFO - 2021-10-12 10:51:50 --> Language Class Initialized
INFO - 2021-10-12 10:51:50 --> Loader Class Initialized
INFO - 2021-10-12 10:51:50 --> Helper loaded: url_helper
INFO - 2021-10-12 10:51:50 --> Helper loaded: form_helper
INFO - 2021-10-12 10:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-12 10:51:50 --> Pagination Class Initialized
INFO - 2021-10-12 10:51:50 --> Controller Class Initialized
INFO - 2021-10-12 10:51:50 --> Upload Class Initialized
INFO - 2021-10-12 10:51:50 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\v_upload_sukses.php
INFO - 2021-10-12 10:51:50 --> Final output sent to browser
DEBUG - 2021-10-12 10:51:50 --> Total execution time: 0.0318
INFO - 2021-10-12 10:52:38 --> Config Class Initialized
INFO - 2021-10-12 10:52:38 --> Hooks Class Initialized
DEBUG - 2021-10-12 10:52:38 --> UTF-8 Support Enabled
INFO - 2021-10-12 10:52:38 --> Utf8 Class Initialized
INFO - 2021-10-12 10:52:38 --> URI Class Initialized
INFO - 2021-10-12 10:52:38 --> Router Class Initialized
INFO - 2021-10-12 10:52:38 --> Output Class Initialized
INFO - 2021-10-12 10:52:38 --> Security Class Initialized
DEBUG - 2021-10-12 10:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 10:52:38 --> CSRF cookie sent
