<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-13 06:36:51 --> Config Class Initialized
INFO - 2021-10-13 06:36:51 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:36:51 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:36:51 --> Utf8 Class Initialized
INFO - 2021-10-13 06:36:51 --> URI Class Initialized
INFO - 2021-10-13 06:36:51 --> Router Class Initialized
INFO - 2021-10-13 06:36:51 --> Output Class Initialized
INFO - 2021-10-13 06:36:51 --> Security Class Initialized
DEBUG - 2021-10-13 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:36:51 --> CSRF cookie sent
INFO - 2021-10-13 06:36:51 --> Input Class Initialized
INFO - 2021-10-13 06:36:51 --> Language Class Initialized
INFO - 2021-10-13 06:36:51 --> Loader Class Initialized
INFO - 2021-10-13 06:36:51 --> Helper loaded: url_helper
INFO - 2021-10-13 06:36:51 --> Helper loaded: form_helper
INFO - 2021-10-13 06:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:36:51 --> Pagination Class Initialized
INFO - 2021-10-13 06:36:51 --> Controller Class Initialized
INFO - 2021-10-13 06:36:51 --> Database Driver Class Initialized
INFO - 2021-10-13 06:36:51 --> Model "Buku_m" initialized
INFO - 2021-10-13 06:36:51 --> Form Validation Class Initialized
INFO - 2021-10-13 06:36:52 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_header.php
INFO - 2021-10-13 06:36:52 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\buku_tampil.php
INFO - 2021-10-13 06:36:52 --> File loaded: D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\views\_footer.php
INFO - 2021-10-13 06:36:52 --> Final output sent to browser
DEBUG - 2021-10-13 06:36:52 --> Total execution time: 0.2152
INFO - 2021-10-13 06:36:59 --> Config Class Initialized
INFO - 2021-10-13 06:36:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:36:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:36:59 --> Utf8 Class Initialized
INFO - 2021-10-13 06:36:59 --> URI Class Initialized
INFO - 2021-10-13 06:36:59 --> Router Class Initialized
INFO - 2021-10-13 06:36:59 --> Output Class Initialized
INFO - 2021-10-13 06:36:59 --> Security Class Initialized
DEBUG - 2021-10-13 06:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:36:59 --> CSRF cookie sent
INFO - 2021-10-13 06:36:59 --> Input Class Initialized
INFO - 2021-10-13 06:36:59 --> Language Class Initialized
INFO - 2021-10-13 06:36:59 --> Loader Class Initialized
INFO - 2021-10-13 06:36:59 --> Helper loaded: url_helper
INFO - 2021-10-13 06:36:59 --> Helper loaded: form_helper
INFO - 2021-10-13 06:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:36:59 --> Pagination Class Initialized
INFO - 2021-10-13 06:36:59 --> Controller Class Initialized
ERROR - 2021-10-13 06:36:59 --> Severity: Notice --> Undefined property: zip::$zip D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\controllers\zip.php 15
ERROR - 2021-10-13 06:36:59 --> Severity: error --> Exception: Call to a member function read_file() on null D:\Xampp\xampp_7.4.22\htdocs\simple_project\application\controllers\zip.php 15
INFO - 2021-10-13 06:37:59 --> Config Class Initialized
INFO - 2021-10-13 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:37:59 --> Utf8 Class Initialized
INFO - 2021-10-13 06:37:59 --> URI Class Initialized
INFO - 2021-10-13 06:37:59 --> Router Class Initialized
INFO - 2021-10-13 06:37:59 --> Output Class Initialized
INFO - 2021-10-13 06:37:59 --> Security Class Initialized
DEBUG - 2021-10-13 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:37:59 --> CSRF cookie sent
INFO - 2021-10-13 06:37:59 --> Input Class Initialized
INFO - 2021-10-13 06:37:59 --> Language Class Initialized
INFO - 2021-10-13 06:37:59 --> Loader Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: url_helper
INFO - 2021-10-13 06:37:59 --> Helper loaded: form_helper
INFO - 2021-10-13 06:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:37:59 --> Pagination Class Initialized
INFO - 2021-10-13 06:37:59 --> Controller Class Initialized
INFO - 2021-10-13 06:37:59 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: download_helper
INFO - 2021-10-13 06:37:59 --> Config Class Initialized
INFO - 2021-10-13 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:37:59 --> Utf8 Class Initialized
INFO - 2021-10-13 06:37:59 --> URI Class Initialized
INFO - 2021-10-13 06:37:59 --> Router Class Initialized
INFO - 2021-10-13 06:37:59 --> Output Class Initialized
INFO - 2021-10-13 06:37:59 --> Security Class Initialized
DEBUG - 2021-10-13 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:37:59 --> CSRF cookie sent
INFO - 2021-10-13 06:37:59 --> Input Class Initialized
INFO - 2021-10-13 06:37:59 --> Language Class Initialized
INFO - 2021-10-13 06:37:59 --> Loader Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: url_helper
INFO - 2021-10-13 06:37:59 --> Helper loaded: form_helper
INFO - 2021-10-13 06:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:37:59 --> Pagination Class Initialized
INFO - 2021-10-13 06:37:59 --> Controller Class Initialized
INFO - 2021-10-13 06:37:59 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: download_helper
INFO - 2021-10-13 06:37:59 --> Config Class Initialized
INFO - 2021-10-13 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:37:59 --> Utf8 Class Initialized
INFO - 2021-10-13 06:37:59 --> URI Class Initialized
INFO - 2021-10-13 06:37:59 --> Router Class Initialized
INFO - 2021-10-13 06:37:59 --> Output Class Initialized
INFO - 2021-10-13 06:37:59 --> Security Class Initialized
DEBUG - 2021-10-13 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:37:59 --> CSRF cookie sent
INFO - 2021-10-13 06:37:59 --> Input Class Initialized
INFO - 2021-10-13 06:37:59 --> Language Class Initialized
INFO - 2021-10-13 06:37:59 --> Loader Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: url_helper
INFO - 2021-10-13 06:37:59 --> Helper loaded: form_helper
INFO - 2021-10-13 06:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:37:59 --> Pagination Class Initialized
INFO - 2021-10-13 06:37:59 --> Controller Class Initialized
INFO - 2021-10-13 06:37:59 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:37:59 --> Helper loaded: download_helper
INFO - 2021-10-13 06:38:03 --> Config Class Initialized
INFO - 2021-10-13 06:38:03 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:38:03 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:38:03 --> Utf8 Class Initialized
INFO - 2021-10-13 06:38:03 --> URI Class Initialized
INFO - 2021-10-13 06:38:03 --> Router Class Initialized
INFO - 2021-10-13 06:38:03 --> Output Class Initialized
INFO - 2021-10-13 06:38:03 --> Security Class Initialized
DEBUG - 2021-10-13 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:38:03 --> CSRF cookie sent
INFO - 2021-10-13 06:38:03 --> Input Class Initialized
INFO - 2021-10-13 06:38:03 --> Language Class Initialized
INFO - 2021-10-13 06:38:03 --> Loader Class Initialized
INFO - 2021-10-13 06:38:03 --> Helper loaded: url_helper
INFO - 2021-10-13 06:38:03 --> Helper loaded: form_helper
INFO - 2021-10-13 06:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:38:03 --> Pagination Class Initialized
INFO - 2021-10-13 06:38:03 --> Controller Class Initialized
INFO - 2021-10-13 06:38:03 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:38:03 --> Helper loaded: download_helper
INFO - 2021-10-13 06:41:16 --> Config Class Initialized
INFO - 2021-10-13 06:41:16 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:41:16 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:41:16 --> Utf8 Class Initialized
INFO - 2021-10-13 06:41:16 --> URI Class Initialized
INFO - 2021-10-13 06:41:16 --> Router Class Initialized
INFO - 2021-10-13 06:41:16 --> Output Class Initialized
INFO - 2021-10-13 06:41:16 --> Security Class Initialized
DEBUG - 2021-10-13 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:41:16 --> CSRF cookie sent
INFO - 2021-10-13 06:41:16 --> Input Class Initialized
INFO - 2021-10-13 06:41:16 --> Language Class Initialized
INFO - 2021-10-13 06:41:16 --> Loader Class Initialized
INFO - 2021-10-13 06:41:16 --> Helper loaded: url_helper
INFO - 2021-10-13 06:41:16 --> Helper loaded: form_helper
INFO - 2021-10-13 06:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:41:16 --> Pagination Class Initialized
INFO - 2021-10-13 06:41:16 --> Controller Class Initialized
INFO - 2021-10-13 06:41:16 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:41:16 --> Helper loaded: download_helper
INFO - 2021-10-13 06:41:34 --> Config Class Initialized
INFO - 2021-10-13 06:41:34 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:41:34 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:41:34 --> Utf8 Class Initialized
INFO - 2021-10-13 06:41:34 --> URI Class Initialized
INFO - 2021-10-13 06:41:34 --> Router Class Initialized
INFO - 2021-10-13 06:41:34 --> Output Class Initialized
INFO - 2021-10-13 06:41:34 --> Security Class Initialized
DEBUG - 2021-10-13 06:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:41:34 --> CSRF cookie sent
INFO - 2021-10-13 06:41:34 --> Input Class Initialized
INFO - 2021-10-13 06:41:34 --> Language Class Initialized
INFO - 2021-10-13 06:41:34 --> Loader Class Initialized
INFO - 2021-10-13 06:41:34 --> Helper loaded: url_helper
INFO - 2021-10-13 06:41:34 --> Helper loaded: form_helper
INFO - 2021-10-13 06:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:41:34 --> Pagination Class Initialized
INFO - 2021-10-13 06:41:34 --> Controller Class Initialized
INFO - 2021-10-13 06:41:34 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:41:34 --> Helper loaded: download_helper
INFO - 2021-10-13 06:41:36 --> Config Class Initialized
INFO - 2021-10-13 06:41:36 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:41:36 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:41:36 --> Utf8 Class Initialized
INFO - 2021-10-13 06:41:36 --> URI Class Initialized
INFO - 2021-10-13 06:41:36 --> Router Class Initialized
INFO - 2021-10-13 06:41:37 --> Output Class Initialized
INFO - 2021-10-13 06:41:37 --> Security Class Initialized
DEBUG - 2021-10-13 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:41:37 --> CSRF cookie sent
INFO - 2021-10-13 06:41:37 --> Input Class Initialized
INFO - 2021-10-13 06:41:37 --> Language Class Initialized
INFO - 2021-10-13 06:41:37 --> Loader Class Initialized
INFO - 2021-10-13 06:41:37 --> Helper loaded: url_helper
INFO - 2021-10-13 06:41:37 --> Helper loaded: form_helper
INFO - 2021-10-13 06:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:41:37 --> Pagination Class Initialized
INFO - 2021-10-13 06:41:37 --> Controller Class Initialized
INFO - 2021-10-13 06:41:37 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:41:37 --> Helper loaded: download_helper
INFO - 2021-10-13 06:41:37 --> Config Class Initialized
INFO - 2021-10-13 06:41:37 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:41:37 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:41:37 --> Utf8 Class Initialized
INFO - 2021-10-13 06:41:37 --> URI Class Initialized
INFO - 2021-10-13 06:41:37 --> Router Class Initialized
INFO - 2021-10-13 06:41:37 --> Output Class Initialized
INFO - 2021-10-13 06:41:37 --> Security Class Initialized
DEBUG - 2021-10-13 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:41:37 --> CSRF cookie sent
INFO - 2021-10-13 06:41:37 --> Input Class Initialized
INFO - 2021-10-13 06:41:37 --> Language Class Initialized
INFO - 2021-10-13 06:41:37 --> Loader Class Initialized
INFO - 2021-10-13 06:41:37 --> Helper loaded: url_helper
INFO - 2021-10-13 06:41:37 --> Helper loaded: form_helper
INFO - 2021-10-13 06:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:41:37 --> Pagination Class Initialized
INFO - 2021-10-13 06:41:37 --> Controller Class Initialized
INFO - 2021-10-13 06:41:37 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:41:37 --> Helper loaded: download_helper
INFO - 2021-10-13 06:41:40 --> Config Class Initialized
INFO - 2021-10-13 06:41:40 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:41:40 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:41:40 --> Utf8 Class Initialized
INFO - 2021-10-13 06:41:40 --> URI Class Initialized
INFO - 2021-10-13 06:41:40 --> Router Class Initialized
INFO - 2021-10-13 06:41:40 --> Output Class Initialized
INFO - 2021-10-13 06:41:40 --> Security Class Initialized
DEBUG - 2021-10-13 06:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:41:40 --> CSRF cookie sent
INFO - 2021-10-13 06:41:40 --> Input Class Initialized
INFO - 2021-10-13 06:41:40 --> Language Class Initialized
INFO - 2021-10-13 06:41:40 --> Loader Class Initialized
INFO - 2021-10-13 06:41:40 --> Helper loaded: url_helper
INFO - 2021-10-13 06:41:40 --> Helper loaded: form_helper
INFO - 2021-10-13 06:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:41:40 --> Pagination Class Initialized
INFO - 2021-10-13 06:41:40 --> Controller Class Initialized
INFO - 2021-10-13 06:41:40 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:41:40 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:04 --> Config Class Initialized
INFO - 2021-10-13 06:42:04 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:04 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:04 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:04 --> URI Class Initialized
INFO - 2021-10-13 06:42:04 --> Router Class Initialized
INFO - 2021-10-13 06:42:04 --> Output Class Initialized
INFO - 2021-10-13 06:42:04 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:04 --> CSRF cookie sent
INFO - 2021-10-13 06:42:04 --> Input Class Initialized
INFO - 2021-10-13 06:42:04 --> Language Class Initialized
INFO - 2021-10-13 06:42:04 --> Loader Class Initialized
INFO - 2021-10-13 06:42:04 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:04 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:04 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:04 --> Controller Class Initialized
INFO - 2021-10-13 06:42:04 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:04 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:07 --> Config Class Initialized
INFO - 2021-10-13 06:42:07 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:07 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:07 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:07 --> URI Class Initialized
INFO - 2021-10-13 06:42:07 --> Router Class Initialized
INFO - 2021-10-13 06:42:07 --> Output Class Initialized
INFO - 2021-10-13 06:42:07 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:07 --> CSRF cookie sent
INFO - 2021-10-13 06:42:07 --> Input Class Initialized
INFO - 2021-10-13 06:42:07 --> Language Class Initialized
INFO - 2021-10-13 06:42:07 --> Loader Class Initialized
INFO - 2021-10-13 06:42:07 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:07 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:07 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:07 --> Controller Class Initialized
INFO - 2021-10-13 06:42:07 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:07 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:07 --> Config Class Initialized
INFO - 2021-10-13 06:42:07 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:07 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:07 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:07 --> URI Class Initialized
INFO - 2021-10-13 06:42:07 --> Router Class Initialized
INFO - 2021-10-13 06:42:07 --> Output Class Initialized
INFO - 2021-10-13 06:42:07 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:07 --> CSRF cookie sent
INFO - 2021-10-13 06:42:07 --> Input Class Initialized
INFO - 2021-10-13 06:42:07 --> Language Class Initialized
INFO - 2021-10-13 06:42:07 --> Loader Class Initialized
INFO - 2021-10-13 06:42:07 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:07 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:07 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:07 --> Controller Class Initialized
INFO - 2021-10-13 06:42:07 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:07 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:10 --> Config Class Initialized
INFO - 2021-10-13 06:42:10 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:10 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:10 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:10 --> URI Class Initialized
INFO - 2021-10-13 06:42:10 --> Router Class Initialized
INFO - 2021-10-13 06:42:10 --> Output Class Initialized
INFO - 2021-10-13 06:42:10 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:10 --> CSRF cookie sent
INFO - 2021-10-13 06:42:10 --> Input Class Initialized
INFO - 2021-10-13 06:42:10 --> Language Class Initialized
INFO - 2021-10-13 06:42:10 --> Loader Class Initialized
INFO - 2021-10-13 06:42:10 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:10 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:10 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:10 --> Controller Class Initialized
INFO - 2021-10-13 06:42:10 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:10 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:45 --> Config Class Initialized
INFO - 2021-10-13 06:42:45 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:45 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:45 --> URI Class Initialized
INFO - 2021-10-13 06:42:45 --> Router Class Initialized
INFO - 2021-10-13 06:42:45 --> Output Class Initialized
INFO - 2021-10-13 06:42:45 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:45 --> CSRF cookie sent
INFO - 2021-10-13 06:42:45 --> Input Class Initialized
INFO - 2021-10-13 06:42:45 --> Language Class Initialized
INFO - 2021-10-13 06:42:45 --> Loader Class Initialized
INFO - 2021-10-13 06:42:45 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:45 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:45 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:45 --> Controller Class Initialized
INFO - 2021-10-13 06:42:45 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:45 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:48 --> Config Class Initialized
INFO - 2021-10-13 06:42:48 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:48 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:48 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:48 --> URI Class Initialized
INFO - 2021-10-13 06:42:48 --> Router Class Initialized
INFO - 2021-10-13 06:42:48 --> Output Class Initialized
INFO - 2021-10-13 06:42:48 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:48 --> CSRF cookie sent
INFO - 2021-10-13 06:42:48 --> Input Class Initialized
INFO - 2021-10-13 06:42:48 --> Language Class Initialized
INFO - 2021-10-13 06:42:48 --> Loader Class Initialized
INFO - 2021-10-13 06:42:48 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:48 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:48 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:48 --> Controller Class Initialized
INFO - 2021-10-13 06:42:48 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:48 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:48 --> Config Class Initialized
INFO - 2021-10-13 06:42:48 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:48 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:48 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:48 --> URI Class Initialized
INFO - 2021-10-13 06:42:48 --> Router Class Initialized
INFO - 2021-10-13 06:42:48 --> Output Class Initialized
INFO - 2021-10-13 06:42:48 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:48 --> CSRF cookie sent
INFO - 2021-10-13 06:42:48 --> Input Class Initialized
INFO - 2021-10-13 06:42:48 --> Language Class Initialized
INFO - 2021-10-13 06:42:48 --> Loader Class Initialized
INFO - 2021-10-13 06:42:48 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:48 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:48 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:48 --> Controller Class Initialized
INFO - 2021-10-13 06:42:48 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:48 --> Helper loaded: download_helper
INFO - 2021-10-13 06:42:51 --> Config Class Initialized
INFO - 2021-10-13 06:42:51 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:42:51 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:42:51 --> Utf8 Class Initialized
INFO - 2021-10-13 06:42:51 --> URI Class Initialized
INFO - 2021-10-13 06:42:51 --> Router Class Initialized
INFO - 2021-10-13 06:42:51 --> Output Class Initialized
INFO - 2021-10-13 06:42:51 --> Security Class Initialized
DEBUG - 2021-10-13 06:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:42:51 --> CSRF cookie sent
INFO - 2021-10-13 06:42:51 --> Input Class Initialized
INFO - 2021-10-13 06:42:51 --> Language Class Initialized
INFO - 2021-10-13 06:42:51 --> Loader Class Initialized
INFO - 2021-10-13 06:42:51 --> Helper loaded: url_helper
INFO - 2021-10-13 06:42:51 --> Helper loaded: form_helper
INFO - 2021-10-13 06:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:42:51 --> Pagination Class Initialized
INFO - 2021-10-13 06:42:51 --> Controller Class Initialized
INFO - 2021-10-13 06:42:51 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:42:51 --> Helper loaded: download_helper
INFO - 2021-10-13 06:46:18 --> Config Class Initialized
INFO - 2021-10-13 06:46:18 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:46:18 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:46:18 --> Utf8 Class Initialized
INFO - 2021-10-13 06:46:18 --> URI Class Initialized
INFO - 2021-10-13 06:46:18 --> Router Class Initialized
INFO - 2021-10-13 06:46:18 --> Output Class Initialized
INFO - 2021-10-13 06:46:18 --> Security Class Initialized
DEBUG - 2021-10-13 06:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:46:18 --> CSRF cookie sent
INFO - 2021-10-13 06:46:18 --> Input Class Initialized
INFO - 2021-10-13 06:46:18 --> Language Class Initialized
INFO - 2021-10-13 06:46:18 --> Loader Class Initialized
INFO - 2021-10-13 06:46:18 --> Helper loaded: url_helper
INFO - 2021-10-13 06:46:18 --> Helper loaded: form_helper
INFO - 2021-10-13 06:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:46:18 --> Pagination Class Initialized
INFO - 2021-10-13 06:46:18 --> Controller Class Initialized
INFO - 2021-10-13 06:46:18 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:46:18 --> Helper loaded: download_helper
INFO - 2021-10-13 06:46:51 --> Config Class Initialized
INFO - 2021-10-13 06:46:51 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:46:51 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:46:51 --> Utf8 Class Initialized
INFO - 2021-10-13 06:46:51 --> URI Class Initialized
INFO - 2021-10-13 06:46:51 --> Router Class Initialized
INFO - 2021-10-13 06:46:51 --> Output Class Initialized
INFO - 2021-10-13 06:46:51 --> Security Class Initialized
DEBUG - 2021-10-13 06:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:46:51 --> CSRF cookie sent
INFO - 2021-10-13 06:46:51 --> Input Class Initialized
INFO - 2021-10-13 06:46:51 --> Language Class Initialized
INFO - 2021-10-13 06:46:51 --> Loader Class Initialized
INFO - 2021-10-13 06:46:51 --> Helper loaded: url_helper
INFO - 2021-10-13 06:46:51 --> Helper loaded: form_helper
INFO - 2021-10-13 06:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:46:51 --> Pagination Class Initialized
INFO - 2021-10-13 06:46:51 --> Controller Class Initialized
INFO - 2021-10-13 06:46:51 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:46:51 --> Final output sent to browser
DEBUG - 2021-10-13 06:46:51 --> Total execution time: 0.0330
INFO - 2021-10-13 06:53:46 --> Config Class Initialized
INFO - 2021-10-13 06:53:46 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:53:46 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:53:46 --> Utf8 Class Initialized
INFO - 2021-10-13 06:53:46 --> URI Class Initialized
INFO - 2021-10-13 06:53:46 --> Router Class Initialized
INFO - 2021-10-13 06:53:46 --> Output Class Initialized
INFO - 2021-10-13 06:53:46 --> Security Class Initialized
DEBUG - 2021-10-13 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:53:46 --> CSRF cookie sent
INFO - 2021-10-13 06:53:46 --> Input Class Initialized
INFO - 2021-10-13 06:53:46 --> Language Class Initialized
INFO - 2021-10-13 06:53:46 --> Loader Class Initialized
INFO - 2021-10-13 06:53:46 --> Helper loaded: url_helper
INFO - 2021-10-13 06:53:46 --> Helper loaded: form_helper
INFO - 2021-10-13 06:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:53:46 --> Pagination Class Initialized
INFO - 2021-10-13 06:53:46 --> Controller Class Initialized
INFO - 2021-10-13 06:53:46 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:53:46 --> Helper loaded: download_helper
INFO - 2021-10-13 06:53:53 --> Config Class Initialized
INFO - 2021-10-13 06:53:53 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:53:53 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:53:53 --> Utf8 Class Initialized
INFO - 2021-10-13 06:53:53 --> URI Class Initialized
INFO - 2021-10-13 06:53:53 --> Router Class Initialized
INFO - 2021-10-13 06:53:53 --> Output Class Initialized
INFO - 2021-10-13 06:53:53 --> Security Class Initialized
DEBUG - 2021-10-13 06:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:53:53 --> CSRF cookie sent
INFO - 2021-10-13 06:53:53 --> Input Class Initialized
INFO - 2021-10-13 06:53:53 --> Language Class Initialized
INFO - 2021-10-13 06:53:53 --> Loader Class Initialized
INFO - 2021-10-13 06:53:53 --> Helper loaded: url_helper
INFO - 2021-10-13 06:53:53 --> Helper loaded: form_helper
INFO - 2021-10-13 06:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:53:53 --> Pagination Class Initialized
INFO - 2021-10-13 06:53:53 --> Controller Class Initialized
INFO - 2021-10-13 06:53:53 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:53:53 --> Helper loaded: download_helper
INFO - 2021-10-13 06:53:53 --> Config Class Initialized
INFO - 2021-10-13 06:53:53 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:53:53 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:53:53 --> Utf8 Class Initialized
INFO - 2021-10-13 06:53:53 --> URI Class Initialized
INFO - 2021-10-13 06:53:53 --> Router Class Initialized
INFO - 2021-10-13 06:53:53 --> Output Class Initialized
INFO - 2021-10-13 06:53:53 --> Security Class Initialized
DEBUG - 2021-10-13 06:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:53:53 --> CSRF cookie sent
INFO - 2021-10-13 06:53:53 --> Input Class Initialized
INFO - 2021-10-13 06:53:53 --> Language Class Initialized
INFO - 2021-10-13 06:53:53 --> Loader Class Initialized
INFO - 2021-10-13 06:53:53 --> Helper loaded: url_helper
INFO - 2021-10-13 06:53:53 --> Helper loaded: form_helper
INFO - 2021-10-13 06:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:53:53 --> Pagination Class Initialized
INFO - 2021-10-13 06:53:53 --> Controller Class Initialized
INFO - 2021-10-13 06:53:53 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:53:53 --> Helper loaded: download_helper
INFO - 2021-10-13 06:53:56 --> Config Class Initialized
INFO - 2021-10-13 06:53:56 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:53:56 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:53:56 --> Utf8 Class Initialized
INFO - 2021-10-13 06:53:56 --> URI Class Initialized
INFO - 2021-10-13 06:53:56 --> Router Class Initialized
INFO - 2021-10-13 06:53:56 --> Output Class Initialized
INFO - 2021-10-13 06:53:56 --> Security Class Initialized
DEBUG - 2021-10-13 06:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:53:56 --> CSRF cookie sent
INFO - 2021-10-13 06:53:56 --> Input Class Initialized
INFO - 2021-10-13 06:53:56 --> Language Class Initialized
INFO - 2021-10-13 06:53:56 --> Loader Class Initialized
INFO - 2021-10-13 06:53:56 --> Helper loaded: url_helper
INFO - 2021-10-13 06:53:56 --> Helper loaded: form_helper
INFO - 2021-10-13 06:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:53:56 --> Pagination Class Initialized
INFO - 2021-10-13 06:53:56 --> Controller Class Initialized
INFO - 2021-10-13 06:53:56 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:53:56 --> Helper loaded: download_helper
INFO - 2021-10-13 06:54:53 --> Config Class Initialized
INFO - 2021-10-13 06:54:53 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:54:53 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:54:53 --> Utf8 Class Initialized
INFO - 2021-10-13 06:54:53 --> URI Class Initialized
INFO - 2021-10-13 06:54:53 --> Router Class Initialized
INFO - 2021-10-13 06:54:53 --> Output Class Initialized
INFO - 2021-10-13 06:54:53 --> Security Class Initialized
DEBUG - 2021-10-13 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:54:53 --> CSRF cookie sent
INFO - 2021-10-13 06:54:53 --> Input Class Initialized
INFO - 2021-10-13 06:54:53 --> Language Class Initialized
INFO - 2021-10-13 06:54:53 --> Loader Class Initialized
INFO - 2021-10-13 06:54:53 --> Helper loaded: url_helper
INFO - 2021-10-13 06:54:53 --> Helper loaded: form_helper
INFO - 2021-10-13 06:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:54:53 --> Pagination Class Initialized
INFO - 2021-10-13 06:54:53 --> Controller Class Initialized
INFO - 2021-10-13 06:54:53 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:54:53 --> Helper loaded: download_helper
INFO - 2021-10-13 06:54:56 --> Config Class Initialized
INFO - 2021-10-13 06:54:56 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:54:56 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:54:56 --> Utf8 Class Initialized
INFO - 2021-10-13 06:54:56 --> URI Class Initialized
INFO - 2021-10-13 06:54:56 --> Router Class Initialized
INFO - 2021-10-13 06:54:56 --> Output Class Initialized
INFO - 2021-10-13 06:54:56 --> Security Class Initialized
DEBUG - 2021-10-13 06:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:54:56 --> CSRF cookie sent
INFO - 2021-10-13 06:54:56 --> Input Class Initialized
INFO - 2021-10-13 06:54:56 --> Language Class Initialized
INFO - 2021-10-13 06:54:56 --> Loader Class Initialized
INFO - 2021-10-13 06:54:56 --> Helper loaded: url_helper
INFO - 2021-10-13 06:54:56 --> Helper loaded: form_helper
INFO - 2021-10-13 06:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:54:56 --> Pagination Class Initialized
INFO - 2021-10-13 06:54:56 --> Controller Class Initialized
INFO - 2021-10-13 06:54:56 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:54:56 --> Helper loaded: download_helper
INFO - 2021-10-13 06:54:56 --> Config Class Initialized
INFO - 2021-10-13 06:54:56 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:54:56 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:54:56 --> Utf8 Class Initialized
INFO - 2021-10-13 06:54:56 --> URI Class Initialized
INFO - 2021-10-13 06:54:56 --> Router Class Initialized
INFO - 2021-10-13 06:54:56 --> Output Class Initialized
INFO - 2021-10-13 06:54:56 --> Security Class Initialized
DEBUG - 2021-10-13 06:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:54:56 --> CSRF cookie sent
INFO - 2021-10-13 06:54:56 --> Input Class Initialized
INFO - 2021-10-13 06:54:56 --> Language Class Initialized
INFO - 2021-10-13 06:54:56 --> Loader Class Initialized
INFO - 2021-10-13 06:54:56 --> Helper loaded: url_helper
INFO - 2021-10-13 06:54:56 --> Helper loaded: form_helper
INFO - 2021-10-13 06:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:54:56 --> Pagination Class Initialized
INFO - 2021-10-13 06:54:56 --> Controller Class Initialized
INFO - 2021-10-13 06:54:56 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:54:56 --> Helper loaded: download_helper
INFO - 2021-10-13 06:54:59 --> Config Class Initialized
INFO - 2021-10-13 06:54:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:54:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:54:59 --> Utf8 Class Initialized
INFO - 2021-10-13 06:54:59 --> URI Class Initialized
INFO - 2021-10-13 06:54:59 --> Router Class Initialized
INFO - 2021-10-13 06:54:59 --> Output Class Initialized
INFO - 2021-10-13 06:54:59 --> Security Class Initialized
DEBUG - 2021-10-13 06:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:54:59 --> CSRF cookie sent
INFO - 2021-10-13 06:54:59 --> Input Class Initialized
INFO - 2021-10-13 06:54:59 --> Language Class Initialized
INFO - 2021-10-13 06:54:59 --> Loader Class Initialized
INFO - 2021-10-13 06:54:59 --> Helper loaded: url_helper
INFO - 2021-10-13 06:54:59 --> Helper loaded: form_helper
INFO - 2021-10-13 06:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:54:59 --> Pagination Class Initialized
INFO - 2021-10-13 06:54:59 --> Controller Class Initialized
INFO - 2021-10-13 06:54:59 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:54:59 --> Helper loaded: download_helper
INFO - 2021-10-13 06:57:58 --> Config Class Initialized
INFO - 2021-10-13 06:57:58 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:57:58 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:57:58 --> Utf8 Class Initialized
INFO - 2021-10-13 06:57:58 --> URI Class Initialized
INFO - 2021-10-13 06:57:58 --> Router Class Initialized
INFO - 2021-10-13 06:57:58 --> Output Class Initialized
INFO - 2021-10-13 06:57:58 --> Security Class Initialized
DEBUG - 2021-10-13 06:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:57:58 --> CSRF cookie sent
INFO - 2021-10-13 06:57:58 --> Input Class Initialized
INFO - 2021-10-13 06:57:58 --> Language Class Initialized
INFO - 2021-10-13 06:57:58 --> Loader Class Initialized
INFO - 2021-10-13 06:57:58 --> Helper loaded: url_helper
INFO - 2021-10-13 06:57:58 --> Helper loaded: form_helper
INFO - 2021-10-13 06:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:57:58 --> Pagination Class Initialized
INFO - 2021-10-13 06:57:58 --> Controller Class Initialized
INFO - 2021-10-13 06:57:58 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:57:58 --> Helper loaded: download_helper
INFO - 2021-10-13 06:58:00 --> Config Class Initialized
INFO - 2021-10-13 06:58:00 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:58:00 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:58:00 --> Utf8 Class Initialized
INFO - 2021-10-13 06:58:00 --> URI Class Initialized
INFO - 2021-10-13 06:58:00 --> Router Class Initialized
INFO - 2021-10-13 06:58:00 --> Output Class Initialized
INFO - 2021-10-13 06:58:00 --> Security Class Initialized
DEBUG - 2021-10-13 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:58:00 --> CSRF cookie sent
INFO - 2021-10-13 06:58:00 --> Input Class Initialized
INFO - 2021-10-13 06:58:00 --> Language Class Initialized
INFO - 2021-10-13 06:58:00 --> Loader Class Initialized
INFO - 2021-10-13 06:58:00 --> Helper loaded: url_helper
INFO - 2021-10-13 06:58:00 --> Helper loaded: form_helper
INFO - 2021-10-13 06:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:58:00 --> Pagination Class Initialized
INFO - 2021-10-13 06:58:00 --> Controller Class Initialized
INFO - 2021-10-13 06:58:00 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:58:00 --> Helper loaded: download_helper
INFO - 2021-10-13 06:58:00 --> Config Class Initialized
INFO - 2021-10-13 06:58:00 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:58:00 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:58:00 --> Utf8 Class Initialized
INFO - 2021-10-13 06:58:00 --> URI Class Initialized
INFO - 2021-10-13 06:58:00 --> Router Class Initialized
INFO - 2021-10-13 06:58:00 --> Output Class Initialized
INFO - 2021-10-13 06:58:00 --> Security Class Initialized
DEBUG - 2021-10-13 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:58:00 --> CSRF cookie sent
INFO - 2021-10-13 06:58:00 --> Input Class Initialized
INFO - 2021-10-13 06:58:00 --> Language Class Initialized
INFO - 2021-10-13 06:58:00 --> Loader Class Initialized
INFO - 2021-10-13 06:58:00 --> Helper loaded: url_helper
INFO - 2021-10-13 06:58:00 --> Helper loaded: form_helper
INFO - 2021-10-13 06:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:58:00 --> Pagination Class Initialized
INFO - 2021-10-13 06:58:00 --> Controller Class Initialized
INFO - 2021-10-13 06:58:00 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:58:00 --> Helper loaded: download_helper
INFO - 2021-10-13 06:58:03 --> Config Class Initialized
INFO - 2021-10-13 06:58:03 --> Hooks Class Initialized
DEBUG - 2021-10-13 06:58:03 --> UTF-8 Support Enabled
INFO - 2021-10-13 06:58:03 --> Utf8 Class Initialized
INFO - 2021-10-13 06:58:03 --> URI Class Initialized
INFO - 2021-10-13 06:58:03 --> Router Class Initialized
INFO - 2021-10-13 06:58:03 --> Output Class Initialized
INFO - 2021-10-13 06:58:03 --> Security Class Initialized
DEBUG - 2021-10-13 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 06:58:03 --> CSRF cookie sent
INFO - 2021-10-13 06:58:03 --> Input Class Initialized
INFO - 2021-10-13 06:58:03 --> Language Class Initialized
INFO - 2021-10-13 06:58:03 --> Loader Class Initialized
INFO - 2021-10-13 06:58:03 --> Helper loaded: url_helper
INFO - 2021-10-13 06:58:03 --> Helper loaded: form_helper
INFO - 2021-10-13 06:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 06:58:03 --> Pagination Class Initialized
INFO - 2021-10-13 06:58:03 --> Controller Class Initialized
INFO - 2021-10-13 06:58:03 --> Zip Compression Class Initialized
INFO - 2021-10-13 06:58:03 --> Helper loaded: download_helper
INFO - 2021-10-13 08:21:21 --> Config Class Initialized
INFO - 2021-10-13 08:21:21 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:21:21 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:21:21 --> Utf8 Class Initialized
INFO - 2021-10-13 08:21:21 --> URI Class Initialized
INFO - 2021-10-13 08:21:21 --> Router Class Initialized
INFO - 2021-10-13 08:21:21 --> Output Class Initialized
INFO - 2021-10-13 08:21:21 --> Security Class Initialized
DEBUG - 2021-10-13 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:21:21 --> CSRF cookie sent
INFO - 2021-10-13 08:21:21 --> Input Class Initialized
INFO - 2021-10-13 08:21:21 --> Language Class Initialized
INFO - 2021-10-13 08:21:21 --> Loader Class Initialized
INFO - 2021-10-13 08:21:21 --> Helper loaded: url_helper
INFO - 2021-10-13 08:21:21 --> Helper loaded: form_helper
INFO - 2021-10-13 08:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:21:21 --> Pagination Class Initialized
INFO - 2021-10-13 08:21:21 --> Controller Class Initialized
INFO - 2021-10-13 08:21:21 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:21:21 --> Helper loaded: download_helper
INFO - 2021-10-13 08:21:57 --> Config Class Initialized
INFO - 2021-10-13 08:21:57 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:21:57 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:21:57 --> Utf8 Class Initialized
INFO - 2021-10-13 08:21:57 --> URI Class Initialized
INFO - 2021-10-13 08:21:57 --> Router Class Initialized
INFO - 2021-10-13 08:21:57 --> Output Class Initialized
INFO - 2021-10-13 08:21:57 --> Security Class Initialized
DEBUG - 2021-10-13 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:21:57 --> CSRF cookie sent
INFO - 2021-10-13 08:21:57 --> Input Class Initialized
INFO - 2021-10-13 08:21:57 --> Language Class Initialized
INFO - 2021-10-13 08:21:57 --> Loader Class Initialized
INFO - 2021-10-13 08:21:57 --> Helper loaded: url_helper
INFO - 2021-10-13 08:21:57 --> Helper loaded: form_helper
INFO - 2021-10-13 08:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:21:57 --> Pagination Class Initialized
INFO - 2021-10-13 08:21:57 --> Controller Class Initialized
INFO - 2021-10-13 08:21:57 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:21:57 --> Helper loaded: download_helper
INFO - 2021-10-13 08:26:18 --> Config Class Initialized
INFO - 2021-10-13 08:26:18 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:26:18 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:26:18 --> Utf8 Class Initialized
INFO - 2021-10-13 08:26:18 --> URI Class Initialized
INFO - 2021-10-13 08:26:18 --> Router Class Initialized
INFO - 2021-10-13 08:26:18 --> Output Class Initialized
INFO - 2021-10-13 08:26:18 --> Security Class Initialized
DEBUG - 2021-10-13 08:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:26:18 --> CSRF cookie sent
INFO - 2021-10-13 08:26:18 --> Input Class Initialized
INFO - 2021-10-13 08:26:18 --> Language Class Initialized
INFO - 2021-10-13 08:26:18 --> Loader Class Initialized
INFO - 2021-10-13 08:26:18 --> Helper loaded: url_helper
INFO - 2021-10-13 08:26:18 --> Helper loaded: form_helper
INFO - 2021-10-13 08:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:26:18 --> Pagination Class Initialized
INFO - 2021-10-13 08:26:18 --> Controller Class Initialized
INFO - 2021-10-13 08:26:18 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:26:18 --> Helper loaded: download_helper
INFO - 2021-10-13 08:28:06 --> Config Class Initialized
INFO - 2021-10-13 08:28:06 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:28:06 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:28:06 --> Utf8 Class Initialized
INFO - 2021-10-13 08:28:06 --> URI Class Initialized
INFO - 2021-10-13 08:28:06 --> Router Class Initialized
INFO - 2021-10-13 08:28:06 --> Output Class Initialized
INFO - 2021-10-13 08:28:06 --> Security Class Initialized
DEBUG - 2021-10-13 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:28:06 --> CSRF cookie sent
INFO - 2021-10-13 08:28:06 --> Input Class Initialized
INFO - 2021-10-13 08:28:06 --> Language Class Initialized
INFO - 2021-10-13 08:28:06 --> Loader Class Initialized
INFO - 2021-10-13 08:28:06 --> Helper loaded: url_helper
INFO - 2021-10-13 08:28:06 --> Helper loaded: form_helper
INFO - 2021-10-13 08:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:28:06 --> Pagination Class Initialized
INFO - 2021-10-13 08:28:06 --> Controller Class Initialized
INFO - 2021-10-13 08:28:06 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:28:06 --> Helper loaded: download_helper
INFO - 2021-10-13 08:28:57 --> Config Class Initialized
INFO - 2021-10-13 08:28:57 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:28:57 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:28:57 --> Utf8 Class Initialized
INFO - 2021-10-13 08:28:57 --> URI Class Initialized
INFO - 2021-10-13 08:28:57 --> Router Class Initialized
INFO - 2021-10-13 08:28:57 --> Output Class Initialized
INFO - 2021-10-13 08:28:57 --> Security Class Initialized
DEBUG - 2021-10-13 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:28:57 --> CSRF cookie sent
INFO - 2021-10-13 08:28:57 --> Input Class Initialized
INFO - 2021-10-13 08:28:57 --> Language Class Initialized
INFO - 2021-10-13 08:28:57 --> Loader Class Initialized
INFO - 2021-10-13 08:28:57 --> Helper loaded: url_helper
INFO - 2021-10-13 08:28:57 --> Helper loaded: form_helper
INFO - 2021-10-13 08:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:28:57 --> Pagination Class Initialized
INFO - 2021-10-13 08:28:57 --> Controller Class Initialized
INFO - 2021-10-13 08:28:57 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:28:57 --> Helper loaded: download_helper
INFO - 2021-10-13 08:29:37 --> Config Class Initialized
INFO - 2021-10-13 08:29:37 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:29:37 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:29:37 --> Utf8 Class Initialized
INFO - 2021-10-13 08:29:37 --> URI Class Initialized
INFO - 2021-10-13 08:29:37 --> Router Class Initialized
INFO - 2021-10-13 08:29:37 --> Output Class Initialized
INFO - 2021-10-13 08:29:37 --> Security Class Initialized
DEBUG - 2021-10-13 08:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:29:37 --> CSRF cookie sent
INFO - 2021-10-13 08:29:37 --> Input Class Initialized
INFO - 2021-10-13 08:29:37 --> Language Class Initialized
INFO - 2021-10-13 08:29:37 --> Loader Class Initialized
INFO - 2021-10-13 08:29:37 --> Helper loaded: url_helper
INFO - 2021-10-13 08:29:37 --> Helper loaded: form_helper
INFO - 2021-10-13 08:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:29:37 --> Pagination Class Initialized
INFO - 2021-10-13 08:29:37 --> Controller Class Initialized
INFO - 2021-10-13 08:29:37 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:29:37 --> Helper loaded: download_helper
INFO - 2021-10-13 08:30:00 --> Config Class Initialized
INFO - 2021-10-13 08:30:00 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:30:00 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:30:00 --> Utf8 Class Initialized
INFO - 2021-10-13 08:30:00 --> URI Class Initialized
INFO - 2021-10-13 08:30:00 --> Router Class Initialized
INFO - 2021-10-13 08:30:00 --> Output Class Initialized
INFO - 2021-10-13 08:30:00 --> Security Class Initialized
DEBUG - 2021-10-13 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:30:00 --> CSRF cookie sent
INFO - 2021-10-13 08:30:00 --> Input Class Initialized
INFO - 2021-10-13 08:30:00 --> Language Class Initialized
INFO - 2021-10-13 08:30:00 --> Loader Class Initialized
INFO - 2021-10-13 08:30:00 --> Helper loaded: url_helper
INFO - 2021-10-13 08:30:00 --> Helper loaded: form_helper
INFO - 2021-10-13 08:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:30:00 --> Pagination Class Initialized
INFO - 2021-10-13 08:30:00 --> Controller Class Initialized
INFO - 2021-10-13 08:30:00 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:30:00 --> Helper loaded: download_helper
INFO - 2021-10-13 08:35:34 --> Config Class Initialized
INFO - 2021-10-13 08:35:34 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:35:34 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:35:34 --> Utf8 Class Initialized
INFO - 2021-10-13 08:35:34 --> URI Class Initialized
INFO - 2021-10-13 08:35:34 --> Router Class Initialized
INFO - 2021-10-13 08:35:34 --> Output Class Initialized
INFO - 2021-10-13 08:35:34 --> Security Class Initialized
DEBUG - 2021-10-13 08:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:35:34 --> CSRF cookie sent
INFO - 2021-10-13 08:35:34 --> Input Class Initialized
INFO - 2021-10-13 08:35:34 --> Language Class Initialized
INFO - 2021-10-13 08:35:34 --> Loader Class Initialized
INFO - 2021-10-13 08:35:34 --> Helper loaded: url_helper
INFO - 2021-10-13 08:35:34 --> Helper loaded: form_helper
INFO - 2021-10-13 08:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:35:34 --> Pagination Class Initialized
INFO - 2021-10-13 08:35:34 --> Controller Class Initialized
INFO - 2021-10-13 08:35:34 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:35:34 --> Helper loaded: download_helper
INFO - 2021-10-13 08:35:38 --> Config Class Initialized
INFO - 2021-10-13 08:35:38 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:35:38 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:35:38 --> Utf8 Class Initialized
INFO - 2021-10-13 08:35:38 --> URI Class Initialized
INFO - 2021-10-13 08:35:38 --> Router Class Initialized
INFO - 2021-10-13 08:35:38 --> Output Class Initialized
INFO - 2021-10-13 08:35:38 --> Security Class Initialized
DEBUG - 2021-10-13 08:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:35:38 --> CSRF cookie sent
INFO - 2021-10-13 08:35:38 --> Input Class Initialized
INFO - 2021-10-13 08:35:38 --> Language Class Initialized
INFO - 2021-10-13 08:35:38 --> Loader Class Initialized
INFO - 2021-10-13 08:35:38 --> Helper loaded: url_helper
INFO - 2021-10-13 08:35:38 --> Helper loaded: form_helper
INFO - 2021-10-13 08:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:35:38 --> Pagination Class Initialized
INFO - 2021-10-13 08:35:38 --> Controller Class Initialized
INFO - 2021-10-13 08:35:38 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:35:38 --> Helper loaded: download_helper
INFO - 2021-10-13 08:35:38 --> Config Class Initialized
INFO - 2021-10-13 08:35:38 --> Hooks Class Initialized
DEBUG - 2021-10-13 08:35:38 --> UTF-8 Support Enabled
INFO - 2021-10-13 08:35:38 --> Utf8 Class Initialized
INFO - 2021-10-13 08:35:38 --> URI Class Initialized
INFO - 2021-10-13 08:35:38 --> Router Class Initialized
INFO - 2021-10-13 08:35:38 --> Output Class Initialized
INFO - 2021-10-13 08:35:38 --> Security Class Initialized
DEBUG - 2021-10-13 08:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 08:35:38 --> CSRF cookie sent
INFO - 2021-10-13 08:35:38 --> Input Class Initialized
INFO - 2021-10-13 08:35:38 --> Language Class Initialized
INFO - 2021-10-13 08:35:38 --> Loader Class Initialized
INFO - 2021-10-13 08:35:38 --> Helper loaded: url_helper
INFO - 2021-10-13 08:35:38 --> Helper loaded: form_helper
INFO - 2021-10-13 08:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 08:35:38 --> Pagination Class Initialized
INFO - 2021-10-13 08:35:38 --> Controller Class Initialized
INFO - 2021-10-13 08:35:38 --> Zip Compression Class Initialized
INFO - 2021-10-13 08:35:38 --> Helper loaded: download_helper
INFO - 2021-10-13 09:09:02 --> Config Class Initialized
INFO - 2021-10-13 09:09:02 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:09:02 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:09:02 --> Utf8 Class Initialized
INFO - 2021-10-13 09:09:02 --> URI Class Initialized
INFO - 2021-10-13 09:09:02 --> Router Class Initialized
INFO - 2021-10-13 09:09:02 --> Output Class Initialized
INFO - 2021-10-13 09:09:02 --> Security Class Initialized
DEBUG - 2021-10-13 09:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:09:02 --> CSRF cookie sent
INFO - 2021-10-13 09:09:02 --> Input Class Initialized
INFO - 2021-10-13 09:09:02 --> Language Class Initialized
INFO - 2021-10-13 09:09:02 --> Loader Class Initialized
INFO - 2021-10-13 09:09:02 --> Helper loaded: url_helper
INFO - 2021-10-13 09:09:02 --> Helper loaded: form_helper
INFO - 2021-10-13 09:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:09:02 --> Pagination Class Initialized
INFO - 2021-10-13 09:09:02 --> Controller Class Initialized
INFO - 2021-10-13 09:09:02 --> FTP Class Initialized
INFO - 2021-10-13 09:09:07 --> Config Class Initialized
INFO - 2021-10-13 09:09:07 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:09:07 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:09:07 --> Utf8 Class Initialized
INFO - 2021-10-13 09:09:07 --> URI Class Initialized
INFO - 2021-10-13 09:09:07 --> Router Class Initialized
INFO - 2021-10-13 09:09:07 --> Output Class Initialized
INFO - 2021-10-13 09:09:07 --> Security Class Initialized
DEBUG - 2021-10-13 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:09:07 --> CSRF cookie sent
INFO - 2021-10-13 09:09:07 --> Input Class Initialized
INFO - 2021-10-13 09:09:07 --> Language Class Initialized
INFO - 2021-10-13 09:09:07 --> Loader Class Initialized
INFO - 2021-10-13 09:09:07 --> Helper loaded: url_helper
INFO - 2021-10-13 09:09:07 --> Helper loaded: form_helper
INFO - 2021-10-13 09:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:09:07 --> Pagination Class Initialized
INFO - 2021-10-13 09:09:07 --> Controller Class Initialized
INFO - 2021-10-13 09:09:07 --> FTP Class Initialized
INFO - 2021-10-13 09:09:23 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:09:28 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:15:36 --> Config Class Initialized
INFO - 2021-10-13 09:15:36 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:15:36 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:15:36 --> Utf8 Class Initialized
INFO - 2021-10-13 09:15:36 --> URI Class Initialized
INFO - 2021-10-13 09:15:36 --> Router Class Initialized
INFO - 2021-10-13 09:15:36 --> Output Class Initialized
INFO - 2021-10-13 09:15:36 --> Security Class Initialized
DEBUG - 2021-10-13 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:15:36 --> CSRF cookie sent
INFO - 2021-10-13 09:15:36 --> Input Class Initialized
INFO - 2021-10-13 09:15:36 --> Language Class Initialized
INFO - 2021-10-13 09:15:36 --> Loader Class Initialized
INFO - 2021-10-13 09:15:36 --> Helper loaded: url_helper
INFO - 2021-10-13 09:15:36 --> Helper loaded: form_helper
INFO - 2021-10-13 09:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:15:36 --> Pagination Class Initialized
INFO - 2021-10-13 09:15:36 --> Controller Class Initialized
INFO - 2021-10-13 09:15:36 --> FTP Class Initialized
INFO - 2021-10-13 09:15:36 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:15:39 --> Config Class Initialized
INFO - 2021-10-13 09:15:39 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:15:39 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:15:39 --> Utf8 Class Initialized
INFO - 2021-10-13 09:15:39 --> URI Class Initialized
INFO - 2021-10-13 09:15:39 --> Router Class Initialized
INFO - 2021-10-13 09:15:39 --> Output Class Initialized
INFO - 2021-10-13 09:15:39 --> Security Class Initialized
DEBUG - 2021-10-13 09:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:15:39 --> CSRF cookie sent
INFO - 2021-10-13 09:15:39 --> Input Class Initialized
INFO - 2021-10-13 09:15:39 --> Language Class Initialized
INFO - 2021-10-13 09:15:39 --> Loader Class Initialized
INFO - 2021-10-13 09:15:39 --> Helper loaded: url_helper
INFO - 2021-10-13 09:15:39 --> Helper loaded: form_helper
INFO - 2021-10-13 09:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:15:39 --> Pagination Class Initialized
INFO - 2021-10-13 09:15:39 --> Controller Class Initialized
INFO - 2021-10-13 09:15:39 --> FTP Class Initialized
INFO - 2021-10-13 09:15:39 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:15:40 --> Config Class Initialized
INFO - 2021-10-13 09:15:40 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:15:40 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:15:40 --> Utf8 Class Initialized
INFO - 2021-10-13 09:15:40 --> URI Class Initialized
INFO - 2021-10-13 09:15:40 --> Router Class Initialized
INFO - 2021-10-13 09:15:40 --> Output Class Initialized
INFO - 2021-10-13 09:15:40 --> Security Class Initialized
DEBUG - 2021-10-13 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:15:40 --> CSRF cookie sent
INFO - 2021-10-13 09:15:40 --> Input Class Initialized
INFO - 2021-10-13 09:15:40 --> Language Class Initialized
INFO - 2021-10-13 09:15:40 --> Loader Class Initialized
INFO - 2021-10-13 09:15:40 --> Helper loaded: url_helper
INFO - 2021-10-13 09:15:40 --> Helper loaded: form_helper
INFO - 2021-10-13 09:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:15:40 --> Pagination Class Initialized
INFO - 2021-10-13 09:15:40 --> Controller Class Initialized
INFO - 2021-10-13 09:15:40 --> FTP Class Initialized
INFO - 2021-10-13 09:15:40 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:15:59 --> Config Class Initialized
INFO - 2021-10-13 09:15:59 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:15:59 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:15:59 --> Utf8 Class Initialized
INFO - 2021-10-13 09:15:59 --> URI Class Initialized
INFO - 2021-10-13 09:15:59 --> Router Class Initialized
INFO - 2021-10-13 09:15:59 --> Output Class Initialized
INFO - 2021-10-13 09:15:59 --> Security Class Initialized
DEBUG - 2021-10-13 09:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:15:59 --> CSRF cookie sent
INFO - 2021-10-13 09:15:59 --> Input Class Initialized
INFO - 2021-10-13 09:15:59 --> Language Class Initialized
INFO - 2021-10-13 09:15:59 --> Loader Class Initialized
INFO - 2021-10-13 09:15:59 --> Helper loaded: url_helper
INFO - 2021-10-13 09:15:59 --> Helper loaded: form_helper
INFO - 2021-10-13 09:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:15:59 --> Pagination Class Initialized
INFO - 2021-10-13 09:15:59 --> Controller Class Initialized
INFO - 2021-10-13 09:15:59 --> FTP Class Initialized
INFO - 2021-10-13 09:15:59 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:16:00 --> Config Class Initialized
INFO - 2021-10-13 09:16:00 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:16:00 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:16:00 --> Utf8 Class Initialized
INFO - 2021-10-13 09:16:00 --> URI Class Initialized
INFO - 2021-10-13 09:16:00 --> Router Class Initialized
INFO - 2021-10-13 09:16:00 --> Output Class Initialized
INFO - 2021-10-13 09:16:00 --> Security Class Initialized
DEBUG - 2021-10-13 09:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:16:00 --> CSRF cookie sent
INFO - 2021-10-13 09:16:00 --> Input Class Initialized
INFO - 2021-10-13 09:16:00 --> Language Class Initialized
INFO - 2021-10-13 09:16:00 --> Loader Class Initialized
INFO - 2021-10-13 09:16:00 --> Helper loaded: url_helper
INFO - 2021-10-13 09:16:00 --> Helper loaded: form_helper
INFO - 2021-10-13 09:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:16:00 --> Pagination Class Initialized
INFO - 2021-10-13 09:16:00 --> Controller Class Initialized
INFO - 2021-10-13 09:16:00 --> FTP Class Initialized
INFO - 2021-10-13 09:16:00 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:18:21 --> Config Class Initialized
INFO - 2021-10-13 09:18:21 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:18:21 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:18:21 --> Utf8 Class Initialized
INFO - 2021-10-13 09:18:21 --> URI Class Initialized
INFO - 2021-10-13 09:18:21 --> Router Class Initialized
INFO - 2021-10-13 09:18:21 --> Output Class Initialized
INFO - 2021-10-13 09:18:21 --> Security Class Initialized
DEBUG - 2021-10-13 09:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:18:21 --> CSRF cookie sent
INFO - 2021-10-13 09:18:21 --> Input Class Initialized
INFO - 2021-10-13 09:18:21 --> Language Class Initialized
INFO - 2021-10-13 09:18:21 --> Loader Class Initialized
INFO - 2021-10-13 09:18:21 --> Helper loaded: url_helper
INFO - 2021-10-13 09:18:21 --> Helper loaded: form_helper
INFO - 2021-10-13 09:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:18:21 --> Pagination Class Initialized
INFO - 2021-10-13 09:18:21 --> Controller Class Initialized
INFO - 2021-10-13 09:18:21 --> FTP Class Initialized
INFO - 2021-10-13 09:18:42 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:20:09 --> Config Class Initialized
INFO - 2021-10-13 09:20:09 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:20:09 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:20:09 --> Utf8 Class Initialized
INFO - 2021-10-13 09:20:09 --> URI Class Initialized
INFO - 2021-10-13 09:20:09 --> Router Class Initialized
INFO - 2021-10-13 09:20:09 --> Output Class Initialized
INFO - 2021-10-13 09:20:09 --> Security Class Initialized
DEBUG - 2021-10-13 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:20:09 --> CSRF cookie sent
INFO - 2021-10-13 09:20:09 --> Input Class Initialized
INFO - 2021-10-13 09:20:09 --> Language Class Initialized
INFO - 2021-10-13 09:20:09 --> Loader Class Initialized
INFO - 2021-10-13 09:20:09 --> Helper loaded: url_helper
INFO - 2021-10-13 09:20:09 --> Helper loaded: form_helper
INFO - 2021-10-13 09:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:20:09 --> Pagination Class Initialized
INFO - 2021-10-13 09:20:09 --> Controller Class Initialized
INFO - 2021-10-13 09:20:09 --> FTP Class Initialized
INFO - 2021-10-13 09:20:09 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:20:11 --> Config Class Initialized
INFO - 2021-10-13 09:20:11 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:20:11 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:20:11 --> Utf8 Class Initialized
INFO - 2021-10-13 09:20:11 --> URI Class Initialized
INFO - 2021-10-13 09:20:11 --> Router Class Initialized
INFO - 2021-10-13 09:20:11 --> Output Class Initialized
INFO - 2021-10-13 09:20:11 --> Security Class Initialized
DEBUG - 2021-10-13 09:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:20:11 --> CSRF cookie sent
INFO - 2021-10-13 09:20:11 --> Input Class Initialized
INFO - 2021-10-13 09:20:11 --> Language Class Initialized
INFO - 2021-10-13 09:20:11 --> Loader Class Initialized
INFO - 2021-10-13 09:20:11 --> Helper loaded: url_helper
INFO - 2021-10-13 09:20:11 --> Helper loaded: form_helper
INFO - 2021-10-13 09:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:20:11 --> Pagination Class Initialized
INFO - 2021-10-13 09:20:11 --> Controller Class Initialized
INFO - 2021-10-13 09:20:11 --> FTP Class Initialized
INFO - 2021-10-13 09:20:11 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:12 --> Config Class Initialized
INFO - 2021-10-13 09:22:12 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:12 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:12 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:12 --> URI Class Initialized
INFO - 2021-10-13 09:22:12 --> Router Class Initialized
INFO - 2021-10-13 09:22:12 --> Output Class Initialized
INFO - 2021-10-13 09:22:12 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:12 --> CSRF cookie sent
INFO - 2021-10-13 09:22:12 --> Input Class Initialized
INFO - 2021-10-13 09:22:12 --> Language Class Initialized
INFO - 2021-10-13 09:22:12 --> Loader Class Initialized
INFO - 2021-10-13 09:22:12 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:12 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:12 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:12 --> Controller Class Initialized
INFO - 2021-10-13 09:22:12 --> FTP Class Initialized
INFO - 2021-10-13 09:22:12 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:14 --> Config Class Initialized
INFO - 2021-10-13 09:22:14 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:14 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:14 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:14 --> URI Class Initialized
INFO - 2021-10-13 09:22:14 --> Router Class Initialized
INFO - 2021-10-13 09:22:14 --> Output Class Initialized
INFO - 2021-10-13 09:22:14 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:14 --> CSRF cookie sent
INFO - 2021-10-13 09:22:14 --> Input Class Initialized
INFO - 2021-10-13 09:22:14 --> Language Class Initialized
INFO - 2021-10-13 09:22:14 --> Loader Class Initialized
INFO - 2021-10-13 09:22:14 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:14 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:14 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:14 --> Controller Class Initialized
INFO - 2021-10-13 09:22:14 --> FTP Class Initialized
INFO - 2021-10-13 09:22:14 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:15 --> Config Class Initialized
INFO - 2021-10-13 09:22:15 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:15 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:15 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:15 --> URI Class Initialized
INFO - 2021-10-13 09:22:15 --> Router Class Initialized
INFO - 2021-10-13 09:22:15 --> Output Class Initialized
INFO - 2021-10-13 09:22:15 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:15 --> CSRF cookie sent
INFO - 2021-10-13 09:22:15 --> Input Class Initialized
INFO - 2021-10-13 09:22:15 --> Language Class Initialized
INFO - 2021-10-13 09:22:15 --> Loader Class Initialized
INFO - 2021-10-13 09:22:15 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:15 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:15 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:15 --> Controller Class Initialized
INFO - 2021-10-13 09:22:15 --> FTP Class Initialized
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:15 --> Config Class Initialized
INFO - 2021-10-13 09:22:15 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:15 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:15 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:15 --> URI Class Initialized
INFO - 2021-10-13 09:22:15 --> Router Class Initialized
INFO - 2021-10-13 09:22:15 --> Output Class Initialized
INFO - 2021-10-13 09:22:15 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:15 --> CSRF cookie sent
INFO - 2021-10-13 09:22:15 --> Input Class Initialized
INFO - 2021-10-13 09:22:15 --> Language Class Initialized
INFO - 2021-10-13 09:22:15 --> Loader Class Initialized
INFO - 2021-10-13 09:22:15 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:15 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:15 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:15 --> Controller Class Initialized
INFO - 2021-10-13 09:22:15 --> FTP Class Initialized
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:15 --> Config Class Initialized
INFO - 2021-10-13 09:22:15 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:15 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:15 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:15 --> URI Class Initialized
INFO - 2021-10-13 09:22:15 --> Router Class Initialized
INFO - 2021-10-13 09:22:15 --> Output Class Initialized
INFO - 2021-10-13 09:22:15 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:15 --> CSRF cookie sent
INFO - 2021-10-13 09:22:15 --> Input Class Initialized
INFO - 2021-10-13 09:22:15 --> Language Class Initialized
INFO - 2021-10-13 09:22:15 --> Loader Class Initialized
INFO - 2021-10-13 09:22:15 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:15 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:15 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:15 --> Controller Class Initialized
INFO - 2021-10-13 09:22:15 --> FTP Class Initialized
INFO - 2021-10-13 09:22:15 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:16 --> Config Class Initialized
INFO - 2021-10-13 09:22:16 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:16 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:16 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:16 --> URI Class Initialized
INFO - 2021-10-13 09:22:16 --> Router Class Initialized
INFO - 2021-10-13 09:22:16 --> Output Class Initialized
INFO - 2021-10-13 09:22:16 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:16 --> CSRF cookie sent
INFO - 2021-10-13 09:22:16 --> Input Class Initialized
INFO - 2021-10-13 09:22:16 --> Language Class Initialized
INFO - 2021-10-13 09:22:16 --> Loader Class Initialized
INFO - 2021-10-13 09:22:16 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:16 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:16 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:16 --> Controller Class Initialized
INFO - 2021-10-13 09:22:16 --> FTP Class Initialized
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:16 --> Config Class Initialized
INFO - 2021-10-13 09:22:16 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:16 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:16 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:16 --> URI Class Initialized
INFO - 2021-10-13 09:22:16 --> Router Class Initialized
INFO - 2021-10-13 09:22:16 --> Output Class Initialized
INFO - 2021-10-13 09:22:16 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:16 --> CSRF cookie sent
INFO - 2021-10-13 09:22:16 --> Input Class Initialized
INFO - 2021-10-13 09:22:16 --> Language Class Initialized
INFO - 2021-10-13 09:22:16 --> Loader Class Initialized
INFO - 2021-10-13 09:22:16 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:16 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:16 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:16 --> Controller Class Initialized
INFO - 2021-10-13 09:22:16 --> FTP Class Initialized
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:16 --> Config Class Initialized
INFO - 2021-10-13 09:22:16 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:16 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:16 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:16 --> URI Class Initialized
INFO - 2021-10-13 09:22:16 --> Router Class Initialized
INFO - 2021-10-13 09:22:16 --> Output Class Initialized
INFO - 2021-10-13 09:22:16 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:16 --> CSRF cookie sent
INFO - 2021-10-13 09:22:16 --> Input Class Initialized
INFO - 2021-10-13 09:22:16 --> Language Class Initialized
INFO - 2021-10-13 09:22:16 --> Loader Class Initialized
INFO - 2021-10-13 09:22:16 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:16 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:16 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:16 --> Controller Class Initialized
INFO - 2021-10-13 09:22:16 --> FTP Class Initialized
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:16 --> Config Class Initialized
INFO - 2021-10-13 09:22:16 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:16 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:16 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:16 --> URI Class Initialized
INFO - 2021-10-13 09:22:16 --> Router Class Initialized
INFO - 2021-10-13 09:22:16 --> Output Class Initialized
INFO - 2021-10-13 09:22:16 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:16 --> CSRF cookie sent
INFO - 2021-10-13 09:22:16 --> Input Class Initialized
INFO - 2021-10-13 09:22:16 --> Language Class Initialized
INFO - 2021-10-13 09:22:16 --> Loader Class Initialized
INFO - 2021-10-13 09:22:16 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:16 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:16 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:16 --> Controller Class Initialized
INFO - 2021-10-13 09:22:16 --> FTP Class Initialized
INFO - 2021-10-13 09:22:16 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:17 --> Config Class Initialized
INFO - 2021-10-13 09:22:17 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:17 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:17 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:17 --> URI Class Initialized
INFO - 2021-10-13 09:22:17 --> Router Class Initialized
INFO - 2021-10-13 09:22:17 --> Output Class Initialized
INFO - 2021-10-13 09:22:17 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:17 --> CSRF cookie sent
INFO - 2021-10-13 09:22:17 --> Input Class Initialized
INFO - 2021-10-13 09:22:17 --> Language Class Initialized
INFO - 2021-10-13 09:22:17 --> Loader Class Initialized
INFO - 2021-10-13 09:22:17 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:17 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:17 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:17 --> Controller Class Initialized
INFO - 2021-10-13 09:22:17 --> FTP Class Initialized
INFO - 2021-10-13 09:22:17 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:22:17 --> Config Class Initialized
INFO - 2021-10-13 09:22:17 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:22:17 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:22:17 --> Utf8 Class Initialized
INFO - 2021-10-13 09:22:17 --> URI Class Initialized
INFO - 2021-10-13 09:22:17 --> Router Class Initialized
INFO - 2021-10-13 09:22:17 --> Output Class Initialized
INFO - 2021-10-13 09:22:17 --> Security Class Initialized
DEBUG - 2021-10-13 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:22:17 --> CSRF cookie sent
INFO - 2021-10-13 09:22:17 --> Input Class Initialized
INFO - 2021-10-13 09:22:17 --> Language Class Initialized
INFO - 2021-10-13 09:22:17 --> Loader Class Initialized
INFO - 2021-10-13 09:22:17 --> Helper loaded: url_helper
INFO - 2021-10-13 09:22:17 --> Helper loaded: form_helper
INFO - 2021-10-13 09:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:22:17 --> Pagination Class Initialized
INFO - 2021-10-13 09:22:17 --> Controller Class Initialized
INFO - 2021-10-13 09:22:17 --> FTP Class Initialized
INFO - 2021-10-13 09:22:17 --> Language file loaded: language/english/ftp_lang.php
INFO - 2021-10-13 09:32:21 --> Config Class Initialized
INFO - 2021-10-13 09:32:21 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:32:21 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:32:21 --> Utf8 Class Initialized
INFO - 2021-10-13 09:32:21 --> URI Class Initialized
INFO - 2021-10-13 09:32:21 --> Router Class Initialized
INFO - 2021-10-13 09:32:21 --> Output Class Initialized
INFO - 2021-10-13 09:32:21 --> Security Class Initialized
DEBUG - 2021-10-13 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:32:21 --> CSRF cookie sent
INFO - 2021-10-13 09:32:21 --> Input Class Initialized
INFO - 2021-10-13 09:32:21 --> Language Class Initialized
INFO - 2021-10-13 09:32:21 --> Loader Class Initialized
INFO - 2021-10-13 09:32:21 --> Helper loaded: url_helper
INFO - 2021-10-13 09:32:21 --> Helper loaded: form_helper
INFO - 2021-10-13 09:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:32:21 --> Pagination Class Initialized
INFO - 2021-10-13 09:32:21 --> Controller Class Initialized
INFO - 2021-10-13 09:32:21 --> Image Lib Class Initialized
INFO - 2021-10-13 09:32:21 --> Final output sent to browser
DEBUG - 2021-10-13 09:32:21 --> Total execution time: 0.2557
INFO - 2021-10-13 09:34:01 --> Config Class Initialized
INFO - 2021-10-13 09:34:01 --> Hooks Class Initialized
DEBUG - 2021-10-13 09:34:01 --> UTF-8 Support Enabled
INFO - 2021-10-13 09:34:01 --> Utf8 Class Initialized
INFO - 2021-10-13 09:34:01 --> URI Class Initialized
INFO - 2021-10-13 09:34:01 --> Router Class Initialized
INFO - 2021-10-13 09:34:01 --> Output Class Initialized
INFO - 2021-10-13 09:34:01 --> Security Class Initialized
DEBUG - 2021-10-13 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 09:34:01 --> CSRF cookie sent
INFO - 2021-10-13 09:34:01 --> Input Class Initialized
INFO - 2021-10-13 09:34:01 --> Language Class Initialized
INFO - 2021-10-13 09:34:01 --> Loader Class Initialized
INFO - 2021-10-13 09:34:01 --> Helper loaded: url_helper
INFO - 2021-10-13 09:34:01 --> Helper loaded: form_helper
INFO - 2021-10-13 09:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-10-13 09:34:01 --> Pagination Class Initialized
INFO - 2021-10-13 09:34:01 --> Controller Class Initialized
INFO - 2021-10-13 09:34:01 --> Image Lib Class Initialized
INFO - 2021-10-13 09:34:01 --> Final output sent to browser
DEBUG - 2021-10-13 09:34:01 --> Total execution time: 0.0846
